package com.cn.media.playback;

/** Counters for the current playback timeline. Audio counts are interleaved sample frames. */
public final class PlaybackStats {
    public final long audioFramesWritten, audioFramesConsumed, videoFramesSubmitted, videoFramesDropped;
    public final long maxSubmissionGapMs;
    /** Latest submitted video timestamp minus the internal media clock, in microseconds. */
    public final long lastVideoOffsetUs;

    PlaybackStats(long written, long consumed, long submitted, long dropped, long gap, long offset) {
        audioFramesWritten = written;
        audioFramesConsumed = consumed;
        videoFramesSubmitted = submitted;
        videoFramesDropped = dropped;
        maxSubmissionGapMs = gap;
        lastVideoOffsetUs = offset;
    }

    static final PlaybackStats EMPTY = new PlaybackStats(0, 0, 0, 0, 0, 0);
}
