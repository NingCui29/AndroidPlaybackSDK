package com.cn.media.playback;

import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/** AVC/HEVC configuration records and Annex B access units. Packet order and PTS stay with the demuxer. */
final class NalAdapter {
    static final int LIMIT = 4 * 1024 * 1024;
    private final boolean hevc;
    private final List<byte[]> sets = new ArrayList<>();
    private int lengthBytes, storedBytes;

    NalAdapter(boolean hevc, ByteBuffer extra) {
        this.hevc = hevc;
        if (extra == null || !extra.hasRemaining()) return;
        ByteBuffer b = extra.slice();
        check(b.remaining() <= LIMIT);
        if (b.get(0) != 1) { collect(b); return; }
        if (hevc) {
            check(b.remaining() >= 23);
            lengthBytes = (b.get(21) & 3) + 1;
            b.position(22);
            int arrays = unsigned(b);
            for (int i = 0; i < arrays; i++) {
                unsigned(b);
                int count = word(b);
                for (int n = 0; n < count; n++) record(b);
            }
        } else {
            check(b.remaining() >= 7);
            lengthBytes = (b.get(4) & 3) + 1;
            b.position(5);
            int sps = unsigned(b) & 31;
            for (int i = 0; i < sps; i++) record(b);
            int pps = unsigned(b);
            for (int i = 0; i < pps; i++) record(b);
        }
    }

    private static void check(boolean valid) {
        if (!valid) throw new IllegalArgumentException("Malformed or oversized video access unit");
    }

    private static int unsigned(ByteBuffer b) { check(b.hasRemaining()); return b.get() & 255; }
    private static int word(ByteBuffer b) { return (unsigned(b) << 8) | unsigned(b); }

    private int type(int first) { return hevc ? (first >> 1) & 63 : first & 31; }

    private boolean parameter(int type) {
        return hevc ? type >= 32 && type <= 34 : type == 7 || type == 8;
    }

    private void record(ByteBuffer b) {
        int size = word(b);
        check(size > 0 && size <= b.remaining());
        int end = b.position() + size;
        addSet(b, b.position(), end);
        b.position(end);
    }

    private void addSet(ByteBuffer b, int begin, int end) {
        if (!parameter(type(b.get(begin)))) return;
        ByteBuffer part = b.duplicate();
        part.position(begin).limit(end);
        byte[] bytes = new byte[part.remaining()];
        part.get(bytes);
        for (byte[] set : sets) if (Arrays.equals(bytes, set)) return;
        check(sets.size() < 64 && bytes.length <= LIMIT - storedBytes - 4);
        sets.add(bytes);
        storedBytes += bytes.length + 4;
    }

    private static int start(ByteBuffer b, int pos) {
        for (int i = pos; i + 2 < b.limit(); i++)
            if (b.get(i) == 0 && b.get(i + 1) == 0 && b.get(i + 2) == 1) return i;
        return -1;
    }

    private interface Visitor { void nal(ByteBuffer data, int begin, int end); }
    private void visit(ByteBuffer data, Visitor visitor) {
        ByteBuffer b = data.slice();
        check(b.remaining() > 0 && b.remaining() <= LIMIT);
        if (lengthBytes != 0) {
            while (b.hasRemaining()) {
                check(b.remaining() >= lengthBytes);
                long size = 0;
                for (int i = 0; i < lengthBytes; i++) size = (size << 8) | unsigned(b);
                check(size > 0 && size <= b.remaining());
                int end = b.position() + (int)size;
                visitor.nal(b, b.position(), end);
                b.position(end);
            }
        } else {
            int prefix = start(b, 0);
            check(prefix >= 0);
            for (int i = 0; i < prefix; ++i) check(b.get(i) == 0);
            while (prefix >= 0) {
                int begin = prefix + 3;
                prefix = start(b, begin);
                int end = prefix < 0 ? b.limit() : prefix;
                while (end > begin && b.get(end - 1) == 0) end--;
                check(end > begin);
                visitor.nal(b, begin, end);
            }
        }
    }

    void collect(ByteBuffer packet) { visit(packet, this::addSet); }

    boolean complete() {
        int mask = 0;
        for (byte[] set : sets) mask |= 1 << (type(set[0]) - (hevc ? 32 : 7));
        return mask == (hevc ? 7 : 3);
    }

    ByteBuffer configuration(int index) {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        int first = hevc ? 32 : 7 + index, last = hevc ? 34 : first;
        for (int type = first; type <= last; type++) {
            for (byte[] set : sets) if (type(set[0]) == type) {
                bytes.write(0); bytes.write(0); bytes.write(0); bytes.write(1);
                bytes.write(set, 0, set.length);
            }
        }
        return ByteBuffer.wrap(bytes.toByteArray());
    }

    int copy(ByteBuffer packet, ByteBuffer output, boolean configuredWithThisPacket) {
        int base = output.position();
        visit(packet, (data, begin, end) -> {
            if (configuredWithThisPacket && parameter(type(data.get(begin)))) return;
            int size = end - begin;
            check(size + 4 <= output.remaining() && size + 4 <= LIMIT - (output.position() - base));
            output.put((byte)0).put((byte)0).put((byte)0).put((byte)1);
            ByteBuffer part = data.duplicate();
            part.position(begin).limit(end);
            output.put(part);
        });
        return output.position() - base;
    }
}
