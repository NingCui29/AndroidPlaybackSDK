package com.cn.media.playback;

import android.os.Handler;
import android.os.Looper;
import java.util.Objects;
import java.util.concurrent.Executor;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

/** Immutable per-player policy. Public time values are milliseconds. */
public final class PlayerConfig {
    public enum VideoMode { AUTO, SOFTWARE_ONLY, HARDWARE_ONLY }

    public final int progressIntervalMs;
    public final VideoMode videoMode;
    public final boolean requireAllSelectedTracks;
    public final Executor callbackExecutor;
    final Set<String> verifiedLegacyCodecs;
    final CodecCalls codecCalls;

    private PlayerConfig(Builder builder) {
        progressIntervalMs = builder.progressIntervalMs;
        videoMode = builder.videoMode;
        requireAllSelectedTracks = builder.requireAllSelectedTracks;
        verifiedLegacyCodecs = Collections.unmodifiableSet(new HashSet<>(builder.verifiedLegacyCodecs));
        codecCalls = builder.codecCalls;
        if (builder.callbackExecutor == null) {
            Handler main = new Handler(Looper.getMainLooper());
            callbackExecutor = command -> main.post(command);
        } else {
            callbackExecutor = builder.callbackExecutor;
        }
    }

    public static final class Builder {
        private int progressIntervalMs = 250;
        private VideoMode videoMode = VideoMode.AUTO;
        private boolean requireAllSelectedTracks;
        private Executor callbackExecutor;
        private final Set<String> verifiedLegacyCodecs = new HashSet<>();
        CodecCalls codecCalls = new CodecCalls();

        /** API 23–28: use a decoder only on the exact firmware on which hardware operation was verified. */
        public Builder addVerifiedHardwareDecoder(String fingerprint, String componentName) {
            Objects.requireNonNull(fingerprint);
            Objects.requireNonNull(componentName);
            if (fingerprint.equals(android.os.Build.FINGERPRINT)) verifiedLegacyCodecs.add(componentName);
            return this;
        }

        public Builder setProgressIntervalMs(int interval) {
            if (interval != 0 && (interval < 100 || interval > 1000)) {
                throw new IllegalArgumentException("Expected zero or 100 to 1000 ms");
            }
            progressIntervalMs = interval;
            return this;
        }

        public Builder setVideoMode(VideoMode mode) {
            videoMode = Objects.requireNonNull(mode);
            return this;
        }

        public Builder setRequireAllSelectedTracks(boolean strict) {
            requireAllSelectedTracks = strict;
            return this;
        }

        public Builder setCallbackExecutor(Executor executor) {
            callbackExecutor = Objects.requireNonNull(executor);
            return this;
        }

        public PlayerConfig build() {
            return new PlayerConfig(this);
        }
    }
}
