package com.cn.media.playback;

/** Immutable stream description. Its identity belongs to the media session that issued it. */
public final class TrackInfo {
    public enum Type { AUDIO, VIDEO, SUBTITLE, OTHER }
    public final long mediaId;
    public final int index;
    public final Type type;
    public final String codec;
    public final String language;
    public final boolean defaultTrack, coverArt, softwareDecodable;
    public final int width, height, sampleRate, channels, rotationDegrees;

    TrackInfo(long mediaId, int index, int type, String codec, String language, boolean defaultTrack,
              boolean coverArt, boolean softwareDecodable, int width, int height, int sampleRate, int channels, int rotation) {
        this.mediaId = mediaId;
        this.index = index;
        this.type = Type.values()[type];
        this.codec = codec;
        this.language = language;
        this.defaultTrack = defaultTrack;
        this.coverArt = coverArt;
        this.softwareDecodable = softwareDecodable;
        this.width = width;
        this.height = height;
        this.sampleRate = sampleRate;
        this.channels = channels;
        this.rotationDegrees = rotation;
    }
}
