package com.cn.media.playback;

import android.os.SystemClock;
import android.view.Surface;
import java.nio.ByteBuffer;

/** One rendering epoch. Decode workers enter via JNI; the control queue owns user intent. */
final class PlaybackOutput implements AutoCloseable {
    interface Observer {
        void ready(PlaybackOutput output, long actualMs);
        void firstAudio(PlaybackOutput output);
        void firstVideo(PlaybackOutput output);
        void backend(PlaybackOutput output, String name);
        void backendFault(PlaybackOutput output, HardwareVideo.Fault failure);
        void videoLost(PlaybackOutput output, int reason);
    }

    private final Observer observer;
    private final PcmOutput pcm = new PcmOutput();
    private final boolean audio;
    private boolean video;
    private boolean paused, stopped, preview, ready, firstAudio, firstVideo, videoBusy, audioEnded;
    private Surface surface;
    private Surface cpuSurface;
    private boolean switching;
    private final long targetUs;
    private final TrackInfo videoTrack;
    private final PlayerConfig policy;
    private final boolean forceSoftware;
    private volatile HardwareVideo hardware;
    private volatile HardwareVideo.Fault lastFault;
    private volatile String backend;
    private int rate;
    private long audioAnchor = -1, clockAnchor, wallAnchor, lastVideo = -1, intervalUs = 33000;
    private long nextVideo = -1, frozenUs;
    private long submitted, lastSubmissionNs, maxGapNs, lastOffsetUs;
    private PlaybackStats finalStats;
    private final long[] recentIntervals = new long[5];
    private int intervalCount, intervalIndex;

    PlaybackOutput(Observer observer, boolean audio, TrackInfo videoTrack, long targetMs,
                   boolean preview, boolean playing, Surface surface, float gain, PlayerConfig policy,
                   boolean forceSoftware) {
        this.observer = observer;
        this.audio = audio;
        this.videoTrack = videoTrack;
        this.video = videoTrack != null;
        this.policy = policy;
        this.forceSoftware = forceSoftware;
        backend = video && (forceSoftware || policy.videoMode == PlayerConfig.VideoMode.SOFTWARE_ONLY) ? "ffmpeg" : "";
        this.targetUs = targetMs * 1000;
        this.preview = preview;
        this.surface = surface;
        paused = !playing;
        clockAnchor = frozenUs = targetUs;
        wallAnchor = nowUs();
        pcm.setGain(gain);
        pcm.setPaused(paused);
    }

    private static long nowUs() { return SystemClock.elapsedRealtimeNanos() / 1000; }

    private void waitForChange(long ms) {
        try { wait(ms); }
        catch (InterruptedException e) { Thread.currentThread().interrupt(); stop(); }
    }

    synchronized void setPlaying(boolean playing) {
        if (playing == !paused || stopped) return;
        frozenUs = clockUs();
        paused = !playing;
        lastSubmissionNs = 0;
        clockAnchor = frozenUs;
        wallAnchor = nowUs();
        pcm.setPaused(paused);
        notifyAll();
    }

    synchronized void setGain(float gain) { pcm.setGain(gain); }

    synchronized void bind(Surface replacement) {
        if (surface == replacement) return;
        if (!audio && replacement == null) frozenUs = clockUs();
        switching = true;
        while (videoBusy) waitForChange(0);
        releaseCpuSurface();
        surface = replacement;
        if (hardware != null) hardware.bind(replacement);
        if (!audio && replacement != null) {
            clockAnchor = frozenUs;
            wallAnchor = nowUs();
        }
        switching = false;
        notifyAll();
    }

    synchronized void stop() {
        if (stopped) return;
        frozenUs = clockUs();
        stopped = true;
        pcm.cancel();
        notifyAll();
    }

    synchronized boolean stopped() { return stopped; }

    String backend() { return backend; }
    void backendSelected(String name) {
        backend = name;
        observer.backend(this, name);
    }
    synchronized void backendFault(HardwareVideo.Fault fault) {
        if (lastFault == fault) return;
        lastFault = fault;
        observer.backendFault(this, fault);
    }
    boolean surfaceSwitchFailed() { return lastFault != null && "hardwareSurface".equals(lastFault.stage); }

    synchronized int initHardware(int profile, int level, int depth, float fps, ByteBuffer extra) {
        if (forceSoftware || policy.videoMode == PlayerConfig.VideoMode.SOFTWARE_ONLY) return 0;
        try {
            hardware = new HardwareVideo(this, videoTrack, surface, extra, profile, level, depth, fps, policy);
            return 1;
        } catch (RuntimeException failure) {
            int outcome = hardwareError(failure, "hardwareSetup");
            if (outcome < 0) return outcome;
            softwareFallback();
            return 0;
        }
    }

    // 0 = accepted, 1 = try software before hardware accepted data,
    // 2 = recover from the current position, negative = terminal or cancellation.
    int hardwarePacket(ByteBuffer packet, long ptsUs, long durationUs, boolean key) {
        try {
            if (packet == null) hardware.finish();
            else hardware.submit(packet, ptsUs, durationUs, key);
            return stopped() ? -3 : 0;
        } catch (RuntimeException failure) {
            return hardwareError(failure, "hardwareDecode");
        }
    }

    private synchronized int hardwareError(RuntimeException failure, String stage) {
        if (stopped) return -3;
        HardwareVideo decoder = hardware;
        boolean runtime = decoder != null && decoder.started();
        HardwareVideo.Fault fault = failure instanceof HardwareVideo.Fault ?
                (HardwareVideo.Fault)failure : new HardwareVideo.Fault(stage, decoder == null ? "" : decoder.component(), failure);
        backendFault(fault);
        if (decoder != null) decoder.close();
        hardware = null;
        if (policy.videoMode == PlayerConfig.VideoMode.HARDWARE_ONLY) return runtime ? -2 : -1;
        return runtime ? 2 : 1;
    }

    synchronized void softwareFallback() { firstVideo = false; backendSelected("ffmpeg"); }

    synchronized int videoUnavailable(int reason) {
        if (stopped || !audio || policy.requireAllSelectedTracks ||
                policy.videoMode == PlayerConfig.VideoMode.HARDWARE_ONLY) return 0;
        video = false;
        backend = "";
        observer.videoLost(this, reason);
        if (audioAnchor >= 0) signalReady(audioAnchor);
        notifyAll();
        return 1;
    }

    private long clockUs() {
        if (stopped || paused || (!audio && surface == null)) return frozenUs;
        if (audio && !audioEnded && audioAnchor >= 0 && rate > 0) {
            long consumed = pcm.consumed();
            if (consumed > 0 && !firstAudio) {
                firstAudio = true;
                observer.firstAudio(this);
            }
            return audioAnchor + consumed * 1000000L / rate;
        }
        if (lastVideo < 0 && !audioEnded) return frozenUs;
        return clockAnchor + Math.max(0, nowUs() - wallAnchor);
    }

    synchronized long positionMs() { return Math.max(0, clockUs() / 1000); }

    synchronized PlaybackStats statistics() {
        if (finalStats != null) return finalStats;
        long written = pcm.submitted();
        return new PlaybackStats(written, Math.min(written, pcm.consumed()), submitted, 0,
                maxGapNs / 1000000, lastOffsetUs);
    }

    private void signalReady(long ptsUs) {
        if (ready) return;
        ready = true;
        observer.ready(this, Math.max(0, ptsUs / 1000));
    }

    // Called only for audio frames surviving preroll.
    synchronized int beginAudio(long ptsUs) {
        if (audioAnchor < 0) audioAnchor = ptsUs >= 0 ? ptsUs : targetUs;
        if (!video || surface == null) signalReady(audioAnchor);
        notifyAll();
        return stopped ? -1 : 0;
    }

    synchronized int configure(int inputRate, int channels) {
        if (stopped) return -1;
        rate = pcm.configure(inputRate, channels);
        notifyAll();
        return rate;
    }

    int write(ByteBuffer samples) {
        int status = pcm.write(samples);
        synchronized (this) {
            if (status >= 0 && !stopped) clockUs();
            notifyAll();
        }
        return status;
    }

    int endAudio() {
        long consumed = pcm.drain();
        synchronized (this) {
            if (consumed < 0 || stopped) return -1;
            clockAnchor = frozenUs = clockUs();
            wallAnchor = nowUs();
            audioEnded = true;
            notifyAll();
            return 0;
        }
    }

    // The native worker must pair each non-null return with finishVideo after releasing its window.
    synchronized Surface acquireVideo(long ptsUs, long durationUs) {
        long pts = ptsUs >= 0 ? ptsUs : nextVideo >= 0 ? nextVideo : targetUs;
        if (lastVideo >= 0 && pts > lastVideo && pts - lastVideo <= 500000) {
            recentIntervals[intervalIndex] = pts - lastVideo;
            intervalIndex = (intervalIndex + 1) % recentIntervals.length;
            intervalCount = Math.min(intervalCount + 1, recentIntervals.length);
        }
        if (durationUs > 0) intervalUs = durationUs;
        else if (intervalCount > 0) {
            long[] ordered = java.util.Arrays.copyOf(recentIntervals, intervalCount);
            java.util.Arrays.sort(ordered);
            intervalUs = ordered[ordered.length / 2];
        }
        if (pts + intervalUs <= targetUs) return null;
        boolean reset = lastVideo < 0 || (nextVideo >= 0 && Math.abs(pts - nextVideo) > 500000);
        lastVideo = pts;
        nextVideo = pts + intervalUs;
        if (reset && (audioAnchor < 0 || !audio)) {
            clockAnchor = Math.max(targetUs, pts);
            wallAnchor = nowUs();
        }
        for (;;) {
            if (stopped) return null;
            if (switching) { waitForChange(0); continue; }
            if (surface == null) {
                if (audio) return null;
                waitForChange(0);
                continue;
            }
            if (!paused || preview) {
                long ahead = pts - clockUs();
                if (ahead <= 0 || preview) break;
                waitForChange(Math.min(20, (ahead + 999) / 1000));
            } else {
                waitForChange(0);
            }
        }
        preview = false;
        Surface target = surface;
        if ("ffmpeg".equals(backend)) {
            // CPU-locking the host's native Surface leaves its producer connected
            // until the host destroys it. Own a separate Surface client so that
            // release/reattach can hand the same BufferQueue back to MediaCodec.
            if (cpuSurface == null) {
                android.os.Parcel parcel = android.os.Parcel.obtain();
                try {
                    surface.writeToParcel(parcel, 0);
                    parcel.setDataPosition(0);
                    cpuSurface = Surface.CREATOR.createFromParcel(parcel);
                } finally { parcel.recycle(); }
            }
            target = cpuSurface;
        }
        videoBusy = true;
        return target;
    }

    synchronized void finishVideo(long ptsUs, boolean didSubmit) {
        videoBusy = false;
        notifyAll();
        if (!didSubmit || stopped) return;
        long actual = ptsUs < 0 ? lastVideo : ptsUs;
        long now = SystemClock.elapsedRealtimeNanos();
        if (lastSubmissionNs != 0) maxGapNs = Math.max(maxGapNs, now - lastSubmissionNs);
        lastSubmissionNs = paused ? 0 : now;
        lastOffsetUs = actual - clockUs();
        submitted++;
        if (paused) frozenUs = Math.max(targetUs, actual);
        signalReady(actual);
        if (!firstVideo) {
            firstVideo = true;
            observer.firstVideo(this);
        }
    }

    synchronized int endVideo() {
        while (!stopped && surface != null && nextVideo >= 0 && clockUs() < nextVideo) {
            waitForChange(paused ? 0 : Math.min(20, Math.max(1, (nextVideo - clockUs()) / 1000)));
        }
        return stopped ? -1 : 0;
    }

    private void releaseCpuSurface() {
        if (cpuSurface != null) { cpuSurface.release(); cpuSurface = null; }
    }

    @Override public synchronized void close() {
        if (!stopped) frozenUs = clockUs();
        finalStats = statistics();
        stopped = true;
        pcm.close();
        if (hardware != null) { hardware.close(); hardware = null; }
        releaseCpuSurface();
        surface = null;
        notifyAll();
    }
}
