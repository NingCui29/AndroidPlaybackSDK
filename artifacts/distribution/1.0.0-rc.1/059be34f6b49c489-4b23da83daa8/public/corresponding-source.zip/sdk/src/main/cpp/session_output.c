#include "output_sinks.h"
#include "recovery_gop.h"
#include <libavutil/pixdesc.h>
#include <libavutil/time.h>
#include <libavutil/common.h>
#include <pthread.h>
#include <sys/eventfd.h>

// One epoch, shared until playback_decode_tracks has joined both selected workers.
typedef struct RenderSession {
    PlaybackInput *input;
    JavaVM *vm;
    pthread_key_t attachment;
    jobject output;
    jmethodID begin_audio, end_audio, acquire_video, finish_video, end_video, stop;
    AudioSink audio;
    VideoSink video;
    AVRational audio_time, video_time;
    int64_t origin, target, next_audio;
    jmethodID hardware_packet, software_fallback, position_ms, video_unavailable;
    const AVStream *video_stream;
    RecoveryGop gop;
    SoftwareDecoder fallback;
    int64_t recovery_floor, wait_key_until;
    int video_lost;
} RenderSession;

static void detach_worker(void *opaque) {
    JavaVM *vm = opaque;
    (*vm)->DetachCurrentThread(vm);
}

static JNIEnv *worker_env(RenderSession *s) {
    JNIEnv *env = NULL;
    if ((*s->vm)->GetEnv(s->vm, (void **)&env, JNI_VERSION_1_6) == JNI_OK) return env;
    if ((*s->vm)->AttachCurrentThread(s->vm, &env, NULL) != JNI_OK) return NULL;
    if (pthread_setspecific(s->attachment, s->vm)) {
        detach_worker(s->vm);
        return NULL;
    }
    return env;
}

static int checked(JNIEnv *env, int value) {
    if (!(*env)->ExceptionCheck(env)) return value;
    (*env)->ExceptionClear(env);
    return AVERROR_EXTERNAL;
}

static void interrupt_output(void *opaque) {
    RenderSession *s = opaque;
    while (eventfd_write(s->input->cancel_fd, 1) < 0 && errno == EINTR) {}
    JNIEnv *env = worker_env(s);
    if (env) {
        (*env)->CallVoidMethod(env, s->output, s->stop);
        checked(env, 0);
    }
}

static int64_t frame_us(const AVFrame *frame, AVRational time, int64_t origin) {
    if (frame->best_effort_timestamp == AV_NOPTS_VALUE) return AV_NOPTS_VALUE;
    return av_sat_sub64(av_rescale_q(frame->best_effort_timestamp, time, AV_TIME_BASE_Q), origin);
}

static int audio_frame(void *opaque, const AVFrame *frame) {
    RenderSession *s = opaque;
    JNIEnv *env = worker_env(s);
    if (!env) return AVERROR_EXTERNAL;
    s->audio.env = env;
    int64_t pts = frame_us(frame, s->audio_time, s->origin);
    if (pts == AV_NOPTS_VALUE) pts = s->next_audio;
    if (frame->sample_rate <= 0) return AVERROR_INVALIDDATA;
    s->next_audio = av_sat_add64(pts, av_rescale(frame->nb_samples, 1000000, frame->sample_rate));
    int64_t skip = 0;
    if (pts < s->target) {
        skip = av_rescale_rnd(av_sat_sub64(s->target, pts), frame->sample_rate, 1000000, AV_ROUND_UP);
        if (skip >= frame->nb_samples) return 0;
        pts = av_sat_add64(pts, av_rescale(skip, 1000000, frame->sample_rate));
    }
    int ret = checked(env, (*env)->CallIntMethod(env, s->output, s->begin_audio, (jlong)pts));
    if (ret < 0) return AVERROR_EXIT;
    return checked(env, audio_deliver_from(&s->audio, frame, (int)skip));
}

static int drain_audio(void *opaque) {
    RenderSession *s = opaque;
    JNIEnv *env = worker_env(s);
    if (!env) return AVERROR_EXTERNAL;
    int ret = checked(env, audio_flush(&s->audio));
    if (ret >= 0) ret = checked(env, (*env)->CallIntMethod(env, s->output, s->end_audio));
    return ret < 0 ? AVERROR_EXTERNAL : 0;
}

static int video_frame(void *opaque, const AVFrame *frame) {
    RenderSession *s = opaque;
    JNIEnv *env = worker_env(s);
    if (!env) return AVERROR_EXTERNAL;
    int64_t pts = frame_us(frame, s->video_time, s->origin);
    int64_t duration = frame->duration > 0 ? av_rescale_q(frame->duration, s->video_time, AV_TIME_BASE_Q) : 0;
    if (s->recovery_floor > 0 && pts != AV_NOPTS_VALUE &&
        av_sat_add64(pts, duration) <= s->recovery_floor) return 0;
    jobject surface = (*env)->CallObjectMethod(env, s->output, s->acquire_video, (jlong)pts, (jlong)duration);
    if (!surface) {
        if (checked(env, 0) < 0) return AVERROR_EXTERNAL;
        return s->input->format->interrupt_callback.callback(s->input) ? AVERROR_EXIT : 0;
    }
    s->video.window = ANativeWindow_fromSurface(env, surface);
    int ret = AVERROR_EXTERNAL;
    if (s->video.window) {
        if (ANativeWindow_getFormat(s->video.window) != WINDOW_FORMAT_RGBA_8888 ||
            ANativeWindow_getWidth(s->video.window) != frame->width ||
            ANativeWindow_getHeight(s->video.window) != frame->height) s->video.width = 0;
        ret = video_post(&s->video, frame);
        ANativeWindow_release(s->video.window);
        s->video.window = NULL;
    }
    (*env)->DeleteLocalRef(env, surface);
    ret = checked(env, ret);
    (*env)->CallVoidMethod(env, s->output, s->finish_video, (jlong)pts, (jboolean)(ret >= 0));
    return checked(env, ret);
}

static int drain_video(void *opaque) {
    RenderSession *s = opaque;
    if (s->video_lost) return 0;
    JNIEnv *env = worker_env(s);
    if (!env) return AVERROR_EXTERNAL;
    return checked(env, (*env)->CallIntMethod(env, s->output, s->end_video)) < 0 ? AVERROR_EXTERNAL : 0;
}

static int lose_video(RenderSession *s, JNIEnv *env, int reason) {
    jint allowed = (*env)->CallIntMethod(env, s->output, s->video_unavailable, (jint)reason);
    if (checked(env, allowed) != 1) return reason;
    s->video_lost = 1;
    recovery_gop_clear(&s->gop);
    return 0;
}

static int hardware_packet(void *opaque, const AVPacket *packet) {
    RenderSession *s = opaque;
    if (s->video_lost) return 0;
    JNIEnv *env = worker_env(s);
    if (!env) return AVERROR_EXTERNAL;
    if (s->fallback.codec && !s->wait_key_until)
        return software_decoder_submit(&s->fallback, packet, video_frame, s);
    if (s->wait_key_until) {
        if (!packet || av_gettime_relative() >= s->wait_key_until) return lose_video(s, env, PLAYBACK_HW_RUNTIME);
        if (!(packet->flags & AV_PKT_FLAG_KEY)) return 0;
        s->wait_key_until = 0;
        return software_decoder_submit(&s->fallback, packet, video_frame, s);
    }
    jobject buffer = NULL;
    int64_t pts = AV_NOPTS_VALUE, duration = 0;
    if (packet) {
        if (!packet->size) return 0;
        if (!s->input->seekable) recovery_gop_remember(&s->gop, packet, s->video_time);
        int64_t timestamp = packet->pts;
        if (timestamp == AV_NOPTS_VALUE && !s->video_stream->codecpar->video_delay) timestamp = packet->dts;
        if (timestamp != AV_NOPTS_VALUE) pts = av_sat_sub64(av_rescale_q(timestamp, s->video_time, AV_TIME_BASE_Q), s->origin);
        duration = av_rescale_q(packet->duration, s->video_time, AV_TIME_BASE_Q);
        buffer = (*env)->NewDirectByteBuffer(env, packet->data, packet->size);
        if (!buffer) return AVERROR(ENOMEM);
    }
    int status = (*env)->CallIntMethod(env, s->output, s->hardware_packet, buffer, (jlong)pts,
            (jlong)duration, (jboolean)(packet && (packet->flags & AV_PKT_FLAG_KEY)));
    if (buffer) (*env)->DeleteLocalRef(env, buffer);
    if (checked(env, 0) < 0) return AVERROR_EXTERNAL;
    if (!status) return 0;
    if (status == -3) return AVERROR_EXIT;
    if (status == -1) return PLAYBACK_HW_INIT;
    if (status == -2 || (status == 2 && s->input->seekable)) return PLAYBACK_HW_RUNTIME;
    int ret = software_decoder_open(&s->fallback, s->video_stream);
    if (ret < 0) return lose_video(s, env, ret);
    (*env)->CallVoidMethod(env, s->output, s->software_fallback);
    if (status == 2) s->recovery_floor = (*env)->CallLongMethod(env, s->output, s->position_ms) * 1000;
    if (checked(env, 0) < 0) return AVERROR_EXTERNAL;
    if (s->gop.count) {
        for (unsigned i = 0; ret >= 0 && i < s->gop.count; ++i)
            ret = software_decoder_submit(&s->fallback, s->gop.packets[i], video_frame, s);
        recovery_gop_clear(&s->gop);
        if (!packet && ret >= 0) ret = software_decoder_submit(&s->fallback, NULL, video_frame, s);
    } else if (packet && ((packet->flags & AV_PKT_FLAG_KEY) || status == 1)) {
        ret = software_decoder_submit(&s->fallback, packet, video_frame, s);
    } else if (packet) s->wait_key_until = av_gettime_relative() + 2000000;
    else return lose_video(s, env, PLAYBACK_HW_RUNTIME);
    return ret;
}

JNIEXPORT jint JNICALL Java_com_cn_media_playback_NativeInput_render(JNIEnv *env, jclass cls,
        jlong handle, jint audio, jint video, jlong target_ms, jobject output) {
    PlaybackInput *in = (PlaybackInput *)(intptr_t)handle;
    if (!in->format || (audio < 0 && video < 0) ||
        audio >= (int)in->format->nb_streams || video >= (int)in->format->nb_streams)
        return AVERROR_STREAM_NOT_FOUND;
    RenderSession s = {.input=in, .target=target_ms * 1000, .next_audio=target_ms * 1000};
    s.origin = in->format->start_time == AV_NOPTS_VALUE ? 0 : in->format->start_time;
    s.video.cancel_fd = in->cancel_fd;
    if ((*env)->GetJavaVM(env, &s.vm) != JNI_OK) return AVERROR_EXTERNAL;
    jclass output_type = (*env)->GetObjectClass(env, output);
    if (!output_type) return AVERROR_EXTERNAL;
#define METHOD(field, name, sig) do { s.field = (*env)->GetMethodID(env, output_type, name, sig); \
    if (!s.field) return AVERROR_EXTERNAL; } while (0)
    METHOD(audio.configure, "configure", "(II)I");
    METHOD(audio.write, "write", "(Ljava/nio/ByteBuffer;)I");
    METHOD(begin_audio, "beginAudio", "(J)I");
    METHOD(end_audio, "endAudio", "()I");
    METHOD(acquire_video, "acquireVideo", "(JJ)Landroid/view/Surface;");
    METHOD(finish_video, "finishVideo", "(JZ)V");
    METHOD(end_video, "endVideo", "()I");
    METHOD(stop, "stop", "()V");
    METHOD(hardware_packet, "hardwarePacket", "(Ljava/nio/ByteBuffer;JJZ)I");
    METHOD(software_fallback, "softwareFallback", "()V");
    METHOD(position_ms, "positionMs", "()J");
    METHOD(video_unavailable, "videoUnavailable", "(I)I");
#undef METHOD
    int err = pthread_key_create(&s.attachment, detach_worker);
    if (err) return AVERROR(err);
    s.output = (*env)->NewGlobalRef(env, output);
    s.audio.output = s.output;
    int ret = AVERROR(ENOMEM);
    if (s.output) {
        DecodeTarget targets[2];
        int count = 0;
        if (audio >= 0) {
            s.audio_time = in->format->streams[audio]->time_base;
            targets[count++] = (DecodeTarget){audio, audio_frame, &s, drain_audio, interrupt_output};
        }
        if (video >= 0) {
            s.video_stream = in->format->streams[video];
            s.video_time = s.video_stream->time_base;
            targets[count++] = (DecodeTarget){video, video_frame, &s, drain_video, interrupt_output};
            const AVCodecParameters *p = s.video_stream->codecpar;
            jmethodID init = (*env)->GetMethodID(env, output_type, "initHardware", "(IIIFLjava/nio/ByteBuffer;)I");
            if (!init) { ret = AVERROR_EXTERNAL; goto done; }
            if (p->extradata_size > 4 * 1024 * 1024) { ret = AVERROR(ENOBUFS); goto done; }
            jobject extra = p->extradata_size > 0 ?
                    (*env)->NewDirectByteBuffer(env, p->extradata, p->extradata_size) : NULL;
            if (p->extradata_size && !extra) { ret = AVERROR(ENOMEM); goto done; }
            const AVPixFmtDescriptor *pix = av_pix_fmt_desc_get(p->format);
            AVRational fps = av_guess_frame_rate(in->format, in->format->streams[video], NULL);
            int mode = (*env)->CallIntMethod(env, output, init, p->profile, p->level, pix ? pix->comp[0].depth : 0,
                    fps.den ? (jfloat)av_q2d(fps) : 0.0f, extra);
            if (extra) (*env)->DeleteLocalRef(env, extra);
            if (checked(env, 0) < 0 || mode < 0) { ret = PLAYBACK_HW_INIT; goto done; }
            if (mode == 1) targets[count-1].packet = hardware_packet;
        }
        ret = playback_decode_tracks(in, targets, count);
done:
        (*env)->DeleteGlobalRef(env, s.output);
    }
    software_decoder_close(&s.fallback);
    recovery_gop_clear(&s.gop);
    sws_freeContext(s.video.scale);
    swr_free(&s.audio.swr);
    av_channel_layout_uninit(&s.audio.layout);
    pthread_key_delete(s.attachment);
    return ret;
}
