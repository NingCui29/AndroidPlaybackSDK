package com.cn.media.playback;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/** A snapshot of the input after successful probing. Unknown duration is null. */
public final class MediaInfo {
    public final long mediaId;
    public final Long durationMs;
    public final List<TrackInfo> tracks;
    public final boolean seekable;
    MediaInfo(long mediaId, long durationMs, boolean seekable, TrackInfo[] tracks) {
        this.mediaId = mediaId;
        this.seekable = seekable;
        this.durationMs = durationMs < 0 ? null : durationMs;
        this.tracks = Collections.unmodifiableList(Arrays.asList(tracks.clone()));
    }
}
