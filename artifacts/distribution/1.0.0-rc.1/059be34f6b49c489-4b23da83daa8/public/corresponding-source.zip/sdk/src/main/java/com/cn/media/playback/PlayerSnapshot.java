package com.cn.media.playback;

/** Consistent state as of one control-queue revision. Times are milliseconds. */
public final class PlayerSnapshot {
    public enum State { IDLE, PREPARING, READY, PLAYING, PAUSED, ENDED, ERROR, STOPPING, RELEASING, RELEASED }

    public final long revision, mediaId, timelineId, positionMs;
    public final State state;
    public final boolean playWhenReady, seeking, muted;
    public final float volume;
    /** Null before preparation and after stop or release. */
    public final MediaInfo media;
    /** Null when that stream type has no active track. */
    public final TrackInfo audioTrack, videoTrack;
    public final String videoBackend;
    public final PlayerError error;
    public final PlaybackStats stats;

    PlayerSnapshot(long revision, long mediaId, long timelineId, State state, boolean playWhenReady,
                   boolean seeking, long positionMs, MediaInfo media, TrackInfo audio, TrackInfo video,
                   float volume, boolean muted, String videoBackend, PlayerError error, PlaybackStats stats) {
        this.revision = revision;
        this.mediaId = mediaId;
        this.timelineId = timelineId;
        this.state = state;
        this.playWhenReady = playWhenReady;
        this.seeking = seeking;
        this.positionMs = positionMs;
        this.media = media;
        this.audioTrack = audio;
        this.videoTrack = video;
        this.volume = volume;
        this.muted = muted;
        this.videoBackend = videoBackend;
        this.error = error;
        this.stats = stats;
    }
}
