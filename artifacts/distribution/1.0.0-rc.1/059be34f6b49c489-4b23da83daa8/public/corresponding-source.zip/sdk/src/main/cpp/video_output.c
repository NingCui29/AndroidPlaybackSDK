#include "playback_input.h"
#include "software_decoder.h"
#include <libswscale/swscale.h>
#include <libavutil/pixdesc.h>
#include <android/native_window_jni.h>
#include <poll.h>
#include <libavutil/time.h>
#include <libavutil/common.h>

#include "output_sinks.h"

int video_post(void *opaque, const AVFrame *frame) {
    VideoSink *sink = opaque;
    struct pollfd cancel = {sink->cancel_fd, POLLIN, 0};
    if (poll(&cancel, 1, 0) > 0) return AVERROR_EXIT;
    if (frame->width <= 0 || frame->height <= 0 ||
        (int64_t)frame->width * frame->height * 4 > 32 * 1024 * 1024)
        return AVERROR(ENOMEM);
    if (frame->width != sink->width || frame->height != sink->height) {
        if (ANativeWindow_setBuffersGeometry(sink->window, frame->width, frame->height,
                                             WINDOW_FORMAT_RGBA_8888)) return AVERROR_EXTERNAL;
        sink->width = frame->width;
        sink->height = frame->height;
    }
    sink->scale = sws_getCachedContext(sink->scale, frame->width, frame->height,
            frame->format, frame->width, frame->height, AV_PIX_FMT_RGBA,
            SWS_BILINEAR, NULL, NULL, NULL);
    if (!sink->scale) return AVERROR(ENOMEM);
    int matrix = frame->colorspace;
    if (matrix == AVCOL_SPC_UNSPECIFIED || matrix == AVCOL_SPC_RGB)
        matrix = frame->height <= 576 ? SWS_CS_ITU601 : SWS_CS_ITU709;
    const int *coefficients = sws_getCoefficients(matrix);
    const AVPixFmtDescriptor *desc = av_pix_fmt_desc_get(frame->format);
    int full = frame->color_range == AVCOL_RANGE_JPEG ||
               (frame->color_range == AVCOL_RANGE_UNSPECIFIED && desc &&
               ((desc->flags & AV_PIX_FMT_FLAG_RGB) || !strncmp(desc->name, "yuvj", 4)));
    int ret = sws_setColorspaceDetails(sink->scale, coefficients, full, coefficients, 1,
                                       0, 1 << 16, 1 << 16);
    if (ret < 0) return ret;
    ANativeWindow_Buffer buffer;
    if (ANativeWindow_lock(sink->window, &buffer, NULL)) return AVERROR_EXTERNAL;
    ret = AVERROR_EXTERNAL;
    if (buffer.bits && buffer.format == WINDOW_FORMAT_RGBA_8888 &&
        buffer.width == frame->width && buffer.height == frame->height &&
        buffer.stride >= frame->width && buffer.stride <= INT_MAX / 4) {
        uint8_t *dst[4] = {buffer.bits};
        int stride[4] = {buffer.stride * 4};
        int lines = sws_scale(sink->scale, (const uint8_t *const *)frame->data,
                              frame->linesize, 0, frame->height, dst, stride);
        if (lines == frame->height) ret = 0;
    }
    if (ANativeWindow_unlockAndPost(sink->window)) return AVERROR_EXTERNAL;
    if (ret == 0) sink->posted++;
    return ret;
}

typedef struct TimedVideo {
    VideoSink output;
    AVRational time_base;
    int64_t anchor_pts, anchor_wall, next_pts, interval;
    int anchored;
} TimedVideo;

static int present_video(void *opaque, const AVFrame *frame) {
    TimedVideo *video = opaque;
    int64_t pts = frame->best_effort_timestamp;
    if (pts != AV_NOPTS_VALUE) pts = av_rescale_q(pts, video->time_base, AV_TIME_BASE_Q);
    else if (video->anchored && video->interval > 0) pts = video->next_pts;
    else return video_post(&video->output, frame);
    int64_t now = av_gettime_relative();
    int64_t jump = av_sat_sub64(pts, video->next_pts);
    if (!video->anchored || jump > 500000 || jump < -500000) {
        video->anchor_pts = pts;
        video->anchor_wall = now;
        video->anchored = 1;
    }
    if (frame->duration > 0)
        video->interval = av_rescale_q(frame->duration, video->time_base, AV_TIME_BASE_Q);
    video->next_pts = av_sat_add64(pts, video->interval);
    int64_t target = av_sat_add64(video->anchor_wall, av_sat_sub64(pts, video->anchor_pts));
    struct pollfd cancel = {video->output.cancel_fd, POLLIN, 0};
    while (now < target) {
        int64_t remaining = av_sat_sub64(target, now);
        int status = poll(&cancel, 1, (int)((FFMIN(remaining, 100000) + 999) / 1000));
        if (status > 0) return AVERROR_EXIT;
        if (status < 0 && errno != EINTR) return AVERROR(errno);
        now = av_gettime_relative();
    }
    return video_post(&video->output, frame);
}
JNIEXPORT jint JNICALL Java_com_cn_media_playback_NativeInput_playVideo(
        JNIEnv *env, jclass type, jlong handle, jobject surface) {
    PlaybackInput *in = (PlaybackInput *)(intptr_t)handle;
    int stream = av_find_best_stream(in->format, AVMEDIA_TYPE_VIDEO, -1, -1, NULL, 0);
    if (stream < 0) return stream;
    TimedVideo sink = {.output={.window=ANativeWindow_fromSurface(env, surface), .cancel_fd=in->cancel_fd},
                       .time_base=in->format->streams[stream]->time_base};
    if (!sink.output.window) return AVERROR_EXTERNAL;
    SoftwareDecoder decoder = {0};
    AVPacket *pkt = av_packet_alloc();
    int ret = pkt ? software_decoder_open(&decoder, in->format->streams[stream]) : AVERROR(ENOMEM);
    while (ret >= 0) {
        ret = av_read_frame(in->format, pkt);
        if (ret == AVERROR_EOF) {
            ret = software_decoder_submit(&decoder, NULL, present_video, &sink);
            break;
        }
        if (ret < 0) break;
        if (pkt->stream_index == stream) ret = software_decoder_submit(&decoder, pkt, present_video, &sink);
        av_packet_unref(pkt);
    }
    av_packet_free(&pkt);
    software_decoder_close(&decoder);
    sws_freeContext(sink.output.scale);
    ANativeWindow_release(sink.output.window);
    return ret < 0 ? ret : sink.output.posted;
}

