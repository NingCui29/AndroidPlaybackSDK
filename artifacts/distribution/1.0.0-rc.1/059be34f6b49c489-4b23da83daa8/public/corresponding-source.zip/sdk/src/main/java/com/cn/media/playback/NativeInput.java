package com.cn.media.playback;

import java.io.Closeable;
import java.io.IOException;

/** One preparation worker owns probe/close. The controller can request cancellation concurrently. */
final class NativeInput implements Closeable {
    static { System.loadLibrary("playback"); }
    private long handle;
    private boolean probed, prepared;

    NativeInput(InputRange range) throws IOException {
        handle = create(range.fd.getFd(), range.start, range.length, range.seekable);
        if (handle == 0) throw new IOException("Cannot allocate native input");
    }

    int probe() {
        if (handle == 0 || probed) throw new IllegalStateException("Invalid probe state");
        probed = true;
        int status = probe(handle);
        prepared = status >= 0;
        return status;
    }

    MediaInfo describe(long mediaId) {
        if (!prepared || handle == 0) throw new IllegalStateException("No prepared input");
        return describe(handle, mediaId);
    }

    private static native MediaInfo describe(long handle, long mediaId);

    void rearm() { rearm(handle); }
    int seek(int index, long ms) { return seek(handle, index, ms); }
    int render(int audio, int video, long targetMs, PlaybackOutput output) {
        return render(handle, audio, video, targetMs, output);
    }
    private static native void rearm(long handle);
    private static native int seek(long handle, int index, long ms);
    private static native int render(long handle, int audio, int video, long targetMs, PlaybackOutput output);
    static native int category(int status, boolean probing);
    static native boolean recoverHardware(int status);

    synchronized void cancel() {
        if (handle != 0) cancel(handle);
    }

    @Override public synchronized void close() {
        if (handle != 0) {
            destroy(handle);
            handle = 0;
        }
    }

    int playBoth(PcmOutput pcm, android.view.Surface surface) { return playBoth(handle, pcm, surface); }
    private static native int playBoth(long handle, PcmOutput pcm, android.view.Surface surface);
    int playVideo(android.view.Surface surface) { return playVideo(handle, surface); }
    private static native int playVideo(long handle, android.view.Surface surface);
    int playAudio(PcmOutput output) { return playAudio(handle, output); }
    private static native int playAudio(long handle, PcmOutput output);
    private static native long create(int fd, long start, long length, boolean seekable);
    private static native int probe(long handle);
    private static native void cancel(long handle);
    private static native void destroy(long handle);
}
