#pragma once
#include "playback_input.h"
#include "software_decoder.h"

typedef struct DecodeTarget {
    int stream;
    PlaybackFrameSink sink;
    void *opaque;
    int (*drain)(void *opaque);
    void (*abort)(void *opaque);
    // Optional compressed-input backend. NULL packet signals decoder EOS.
    int (*packet)(void *opaque, const AVPacket *packet);
} DecodeTarget;

// Called by the demux worker. Each target callback runs on its own worker.
// Targets and input must remain valid until the function joins all workers.
int playback_decode_tracks(PlaybackInput *input, const DecodeTarget *targets, int count);
