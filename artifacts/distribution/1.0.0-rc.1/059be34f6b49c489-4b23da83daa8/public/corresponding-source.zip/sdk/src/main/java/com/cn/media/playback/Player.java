package com.cn.media.playback;

import android.content.Context;
import android.os.OperationCanceledException;
import android.view.Surface;

import java.io.IOException;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import static com.cn.media.playback.CommandResult.Status;
import static com.cn.media.playback.PlayerError.Code;
import static com.cn.media.playback.PlayerError.Scope;
import static com.cn.media.playback.PlayerSnapshot.State;

/** One reusable player. All public times are milliseconds; command numbers are per instance. */
public final class Player {
    private final Context context;
    private final PlayerConfig config;
    private final PlayerListener listener;
    private final CallbackQueue callbacks;
    private final ScheduledThreadPoolExecutor control = new ScheduledThreadPoolExecutor(1,
            r -> new Thread(r, "playback-control"));
    private final ExecutorService io = Executors.newSingleThreadExecutor(r -> new Thread(r, "playback-media"));
    private final ArrayDeque<PlayerError> history = new ArrayDeque<>();
    private long sequence, releaseId;

    // Accessed by the control queue only, except the volatile published snapshot.
    private PlaybackSession session;
    private PlaybackOutput output;
    private State state = State.IDLE;
    private MediaInfo media;
    private TrackInfo audio, video;
    private Surface surface;
    private boolean intent, muted;
    private float volume = 1;
    private long pendingOpen, pendingTimeline, timeline, revision, position;
    private ScheduledFuture<?> progress, seekDeadline;
    private PlayerError error;
    private PlaybackStats stats = PlaybackStats.EMPTY;
    private boolean forceSoftware;
    private boolean surfaceRebuilt;
    private String lastBackend = "";
    private volatile PlayerSnapshot latest;

    public Player(Context context, PlayerConfig config, PlayerListener listener) {
        this.context = Objects.requireNonNull(context).getApplicationContext();
        this.config = Objects.requireNonNull(config);
        this.listener = Objects.requireNonNull(listener);
        callbacks = new CallbackQueue(config.callbackExecutor);
        control.setRemoveOnCancelPolicy(true);
        control.setExecuteExistingDelayedTasksAfterShutdownPolicy(false);
        latest = snapshot();
    }

    public PlayerSnapshot getSnapshot() { return latest; }

    public List<PlayerError> getDiagnostics() {
        synchronized (history) { return Collections.unmodifiableList(new ArrayList<>(history)); }
    }

    private interface Command { void run(long id); }

    private synchronized long accept(Command command) {
        if (releaseId != 0) throw new IllegalStateException("Player released");
        long id = ++sequence;
        control.execute(() -> command.run(id));
        return id;
    }

    /** Descriptor validation and duplication are synchronous. File/provider access is asynchronous. */
    public synchronized long open(MediaSource source) throws IOException {
        if (releaseId != 0) throw new IllegalStateException("Player released");
        InputRange admitted = Objects.requireNonNull(source).acquireDescriptor();
        return accept(id -> prepare(new PlaybackSession(id, source, admitted)));
    }

    public long play() { return accept(id -> playbackIntent(id, true)); }
    public long pause() { return accept(id -> playbackIntent(id, false)); }
    public long seekTo(long positionMs) { return accept(id -> seek(id, positionMs)); }

    public long selectAudioTrack(TrackInfo track) {
        return accept(id -> {
            if (media == null || track == null || track.type != TrackInfo.Type.AUDIO ||
                    !media.tracks.contains(track)) { reject(id, Code.TRACK_NOT_FOUND, "selectAudio"); return; }
            if (track == audio) { success(id); return; }
            if (!track.softwareDecodable) { reject(id, Code.TRACK_UNSUPPORTED, "selectAudio"); return; }
            if (output != null && !media.seekable) { reject(id, Code.SEEK_UNAVAILABLE, "selectAudio"); return; }
            position = currentPosition();
            audio = track;
            if (output != null) startRun(position, true, id);
            else { publish(false); success(id); }
        });
    }

    /** The host owns the Surface. Detach completes after the final old-buffer access exits. */
    public long setVideoSurface(Surface replacement) {
        return accept(id -> {
            if (replacement != null && !replacement.isValid()) { reject(id, Code.OUTPUT_LOST, "surface"); return; }
            surface = replacement;
            surfaceRebuilt = false;
            if (output != null) output.bind(replacement);
            if (video != null && audio == null && (state == State.PLAYING || state == State.PAUSED)) {
                state = intent && surface != null ? State.PLAYING : State.PAUSED;
            }
            publish(false);
            success(id);
        });
    }

    public long setVolume(float gain) {
        return accept(id -> {
            if (!(gain >= 0 && gain <= 1)) { reject(id, Code.INVALID_ARGUMENT, "volume"); return; }
            volume = gain;
            if (output != null) output.setGain(muted ? 0 : volume);
            publish(false);
            success(id);
        });
    }

    public long setMuted(boolean value) {
        return accept(id -> {
            muted = value;
            if (output != null) output.setGain(muted ? 0 : volume);
            publish(false);
            success(id);
        });
    }

    public long stop() { return accept(id -> cleanup(id, false)); }

    /** Repeated calls share the same request number and completion. */
    public synchronized long release() {
        if (releaseId != 0) return releaseId;
        releaseId = ++sequence;
        long id = releaseId;
        control.execute(() -> cleanup(id, true));
        return id;
    }

    private long currentPosition() {
        return output == null ? position : clamp(output.positionMs());
    }

    private long clamp(long ms) {
        long value = Math.max(0, ms);
        return media != null && media.durationMs != null ? Math.min(value, media.durationMs) : value;
    }

    private PlayerSnapshot snapshot() {
        return new PlayerSnapshot(++revision, session == null ? 0 : session.id, timeline, state,
                intent, pendingTimeline != 0, currentPosition(), media, audio, video, volume, muted,
                output == null ? lastBackend : output.backend(), error,
                output == null ? stats : output.statistics());
    }

    private void publish(boolean periodic) {
        PlayerSnapshot update = snapshot();
        latest = update;
        callbacks.add(periodic, () -> {
            if (!periodic || (latest.mediaId == update.mediaId && latest.timelineId == update.timelineId &&
                    latest.state == State.PLAYING)) listener.onSnapshot(update);
        });
        if (!periodic) updateTicker();
    }

    private void updateTicker() {
        boolean needed = state == State.PLAYING && config.progressIntervalMs != 0;
        if (!needed && progress != null) { progress.cancel(false); progress = null; }
        if (needed && progress == null) {
            progress = control.scheduleAtFixedRate(() -> publish(true), config.progressIntervalMs,
                    config.progressIntervalMs, TimeUnit.MILLISECONDS);
        }
    }

    private void complete(long id, Status status, PlayerError failure) {
        complete(id, status, failure, null);
    }

    private void complete(long id, Status status, PlayerError failure, Long actualMs) {
        if (id == 0) return;
        CommandResult result = new CommandResult(id, status, failure, latest, actualMs);
        callbacks.add(false, () -> listener.onCommandResult(result));
    }

    private void success(long id) { complete(id, Status.SUCCESS, null); }

    private PlayerError problem(long request, Code code, Scope scope, String stage, int raw) {
        PlayerError failure = new PlayerError(code, scope, session == null ? 0 : session.id, timeline,
                request, stage, output == null ? lastBackend : output.backend(), raw);
        synchronized (history) {
            if (history.size() == 128) history.removeFirst();
            history.addLast(failure);
        }
        return failure;
    }

    private void report(PlayerError failure) {
        PlayerSnapshot at = latest;
        callbacks.add(false, () -> listener.onError(failure, at));
    }

    private void reject(long id, Code code, String stage) {
        PlayerError failure = problem(id, code, Scope.REQUEST, stage, 0);
        report(failure);
        complete(id, Status.FAILED, failure);
    }

    private void endPending(Status terminal) {
        complete(pendingOpen, terminal, null);
        complete(pendingTimeline, terminal, null);
        pendingOpen = pendingTimeline = 0;
        clearSeekDeadline();
    }

    private void clearSeekDeadline() {
        if (seekDeadline != null) { seekDeadline.cancel(false); seekDeadline = null; }
    }

    private void retire() {
        PlaybackSession old = session;
        if (old != null) {
            old.retire();
            io.execute(old::close);
        }
        session = null;
        output = null;
    }

    private void prepare(PlaybackSession next) {
        endPending(Status.SUPERSEDED);
        retire();
        session = next;
        media = null;
        audio = video = null;
        position = 0;
        timeline = 0;
        forceSoftware = false;
        surfaceRebuilt = false;
        lastBackend = "";
        stats = PlaybackStats.EMPTY;
        intent = false;
        error = null;
        state = State.PREPARING;
        pendingOpen = next.id;
        publish(false);
        io.execute(() -> openInput(next));
    }

    private void openInput(PlaybackSession next) {
        ScheduledFuture<?> timeout = control.schedule(() -> {
            if (session == next && pendingOpen == next.id)
                fail(next.id, Code.INPUT_TIMEOUT, "open", 0);
        }, 5, TimeUnit.SECONDS);
        try {
            NativeInput acquired;
            try { acquired = next.acquire(context.getContentResolver()); }
            finally { timeout.cancel(false); }
            if (acquired == null) return;
            int raw = acquired.probe();
            if (raw < 0) {
                Code code = Code.fromNumber(NativeInput.category(raw, true));
                control.execute(() -> openFailed(next, code, "probe", raw));
                return;
            }
            MediaInfo info = acquired.describe(next.id);
            control.execute(() -> prepared(next, info));
        } catch (SecurityException denied) {
            control.execute(() -> openFailed(next, Code.INPUT_PERMISSION, "open", 0));
        } catch (IOException | OperationCanceledException unavailable) {
            control.execute(() -> openFailed(next, Code.INPUT_IO, "open", 0));
        } catch (IllegalArgumentException invalid) {
            control.execute(() -> openFailed(next, Code.INVALID_ARGUMENT, "inputRange", 0));
        }
    }

    private void openFailed(PlaybackSession next, Code code, String stage, int raw) {
        if (session == next && pendingOpen == next.id) fail(next.id, code, stage, raw);
    }

    private static TrackInfo preferred(MediaInfo info, TrackInfo.Type type) {
        TrackInfo selected = null;
        for (TrackInfo track : info.tracks) {
            if (track.type != type || track.coverArt || !track.softwareDecodable) continue;
            if (selected == null || track.defaultTrack) selected = track;
            if (track.defaultTrack) break;
        }
        return selected;
    }

    private void prepared(PlaybackSession next, MediaInfo info) {
        if (session != next || pendingOpen != next.id) return;
        media = info;
        audio = preferred(info, TrackInfo.Type.AUDIO);
        video = preferred(info, TrackInfo.Type.VIDEO);
        if (audio == null && video == null) { fail(next.id, Code.NO_PLAYABLE_TRACK, "trackSelection", 0); return; }
        for (TrackInfo track : info.tracks) {
            boolean missing = (track.type == TrackInfo.Type.AUDIO && audio == null) ||
                    (track.type == TrackInfo.Type.VIDEO && !track.coverArt && video == null);
            if (!missing) continue;
            if (config.requireAllSelectedTracks || (track.type == TrackInfo.Type.VIDEO &&
                    config.videoMode == PlayerConfig.VideoMode.HARDWARE_ONLY)) {
                fail(next.id, Code.TRACK_UNSUPPORTED, "trackSelection", 0);
                return;
            }
            report(problem(next.id, Code.TRACK_UNSUPPORTED, Scope.TRACK, "trackSelection", 0));
            break;
        }
        long id = pendingOpen;
        pendingOpen = 0;
        state = State.READY;
        publish(false);
        success(id);
        if (intent) startRun(0, false, 0);
    }

    private void playbackIntent(long id, boolean playing) {
        if (session == null || state == State.ERROR) { reject(id, Code.INVALID_STATE, "playIntent"); return; }
        if (playing && state == State.ENDED && !media.seekable) {
            reject(id, Code.SEEK_UNAVAILABLE, "replay"); return;
        }
        intent = playing;
        if (state == State.PREPARING || (state == State.ENDED && !playing)) {
            publish(false); success(id); return;
        }
        if (playing && output == null) startRun(0, state == State.ENDED, 0);
        else {
            if (output != null) output.setPlaying(playing);
            state = runningState();
            publish(false);
        }
        success(id);
    }

    private State runningState() {
        return intent && (audio != null || surface != null) ? State.PLAYING : State.PAUSED;
    }

    private void seek(long id, long ms) {
        if (media == null || state == State.ERROR) { reject(id, Code.INVALID_STATE, "seek"); return; }
        if (!media.seekable) { reject(id, Code.SEEK_UNAVAILABLE, "seek"); return; }
        startRun(Math.min(clamp(ms), Long.MAX_VALUE / 1000), true, id);
    }

    private void startRun(long target, boolean seek, long request) {
        complete(pendingTimeline, Status.SUPERSEDED, null);
        clearSeekDeadline();
        pendingTimeline = request;
        timeline++;
        position = target;
        PlaybackSession owner = session;
        int a = audio == null ? -1 : audio.index;
        int v = video == null ? -1 : video.index;
        PlaybackOutput run = new PlaybackOutput(observer, a >= 0, video, target, seek,
                intent, surface, muted ? 0 : volume, config, forceSoftware);
        owner.replace(run);
        output = run;
        state = runningState();
        publish(false);
        if (request != 0) {
            seekDeadline = control.schedule(() -> {
                if (output == run && pendingTimeline == request)
                    fail(request, Code.INPUT_TIMEOUT, "preroll", 0);
            }, 3, TimeUnit.SECONDS);
        }
        io.execute(() -> {
            NativeInput input = owner.enter(run);
            if (input == null) { run.close(); return; }
            int raw;
            try {
                raw = seek ? input.seek(v >= 0 ? v : a, target) : 0;
                if (raw >= 0) raw = input.render(a, v, target, run);
            } finally {
                run.close();
            }
            final int status = raw;
            control.execute(() -> finished(owner, run, status));
        });
    }

    private final PlaybackOutput.Observer observer = new PlaybackOutput.Observer() {
        @Override public void ready(PlaybackOutput run, long actualMs) {
            control.execute(() -> {
                if (output != run || pendingTimeline == 0) return;
                long id = pendingTimeline;
                pendingTimeline = 0;
                clearSeekDeadline();
                position = actualMs;
                publish(false);
                complete(id, Status.SUCCESS, null, actualMs);
            });
        }
        @Override public void firstAudio(PlaybackOutput run) { first(run, true); }
        @Override public void firstVideo(PlaybackOutput run) { first(run, false); }
        @Override public void backend(PlaybackOutput run, String name) {
            control.execute(() -> {
                if (output != run) return;
                if ("ffmpeg".equals(name) && config.videoMode == PlayerConfig.VideoMode.AUTO)
                    forceSoftware = true;
                publish(false);
            });
        }
        @Override public void videoLost(PlaybackOutput run, int raw) {
            control.execute(() -> {
                if (output != run) return;
                video = null;
                publish(false);
                report(problem(pendingTimeline, Code.fromNumber(NativeInput.category(raw, false)),
                        Scope.TRACK, "videoDegraded", raw));
            });
        }
        @Override public void backendFault(PlaybackOutput run, HardwareVideo.Fault failure) {
            control.execute(() -> {
                if (output != run) return;
                Code code = failure.stage.equals("hardwareDecode") || failure.stage.equals("hardwareDrain") ?
                        Code.DECODER_RUNTIME : Code.DECODER_INIT;
                PlayerError item = new PlayerError(code, Scope.TRACK, session.id, timeline, pendingTimeline,
                        failure.stage, failure.component, failure.platformCode);
                synchronized (history) {
                    if (history.size() == 128) history.removeFirst();
                    history.addLast(item);
                }
                report(item);
            });
        }
        private void first(PlaybackOutput run, boolean isAudio) {
            control.execute(() -> {
                if (output != run) return;
                publish(false);
                PlayerSnapshot at = latest;
                callbacks.add(false, () -> {
                    if (isAudio) listener.onFirstAudioConsumption(at);
                    else listener.onFirstVideoSubmission(at);
                });
            });
        }
    };

    private void finished(PlaybackSession owner, PlaybackOutput run, int raw) {
        if (session != owner || output != run) return;
        long at = currentPosition();
        stats = run.statistics();
        lastBackend = run.backend();
        output = null;
        if (raw < 0) {
            Code category = Code.fromNumber(NativeInput.category(raw, false));
            boolean rebuild = run.surfaceSwitchFailed() && !surfaceRebuilt;
            if (NativeInput.recoverHardware(raw) && media.seekable && !forceSoftware &&
                    (rebuild || config.videoMode == PlayerConfig.VideoMode.AUTO)) {
                if (rebuild) surfaceRebuilt = true;
                else forceSoftware = true;
                long request = pendingTimeline;
                pendingTimeline = 0;
                startRun(request != 0 ? position : at, true, request);
                return;
            }
            position = at;
            fail(pendingTimeline, category, "render", raw);
            return;
        }
        state = State.ENDED;
        intent = false;
        position = media.durationMs != null ? media.durationMs : at;
        long id = pendingTimeline;
        pendingTimeline = 0;
        clearSeekDeadline();
        publish(false);
        success(id);
    }

    private void fail(long request, Code code, String stage, int raw) {
        position = currentPosition();
        error = problem(request, code, Scope.SESSION, stage, raw);
        if (session != null) {
            PlaybackSession failed = session;
            failed.retire();
            io.execute(failed::close);
        }
        output = null;
        state = State.ERROR;
        intent = false;
        long open = pendingOpen, seek = pendingTimeline;
        pendingTimeline = pendingOpen = 0;
        clearSeekDeadline();
        publish(false);
        report(error);
        complete(open, Status.FAILED, error);
        complete(seek, Status.FAILED, error);
        if (request != open && request != seek) complete(request, Status.FAILED, error);
    }

    private void cleanup(long id, boolean release) {
        endPending(Status.CANCELLED);
        retire();
        long generation = ++timeline;
        media = null;
        audio = video = null;
        intent = false;
        position = 0;
        stats = PlaybackStats.EMPTY;
        lastBackend = "";
        error = null;
        state = release ? State.RELEASING : State.STOPPING;
        publish(false);
        io.execute(() -> control.execute(() -> {
            if (session == null && timeline == generation) {
                state = release ? State.RELEASED : State.IDLE;
                if (release) {
                    surface = null;
                    synchronized (history) { history.clear(); }
                }
                publish(false);
            }
            success(id);
            if (release) { io.shutdown(); control.shutdown(); }
        }));
    }
}
