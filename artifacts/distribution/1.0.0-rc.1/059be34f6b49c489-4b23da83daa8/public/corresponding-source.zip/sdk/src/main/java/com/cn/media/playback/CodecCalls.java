package com.cn.media.playback;

import android.media.MediaCodec;
import android.media.MediaFormat;
import android.view.Surface;
import java.io.IOException;

/** Platform operations with observable failure boundaries; replaced by the device fault tests. */
class CodecCalls {
    MediaCodec create(String name) throws IOException { return MediaCodec.createByCodecName(name); }
    void configure(MediaCodec codec, MediaFormat format, Surface surface) { codec.configure(format, surface, null, 0); }
    void start(MediaCodec codec) { codec.start(); }
    void queue(MediaCodec codec, int index, int bytes, long pts, int flags) {
        codec.queueInputBuffer(index, 0, bytes, pts, flags);
    }
}
