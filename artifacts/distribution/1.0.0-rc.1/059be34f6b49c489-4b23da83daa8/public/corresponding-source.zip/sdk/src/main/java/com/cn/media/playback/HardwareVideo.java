package com.cn.media.playback;

import android.graphics.SurfaceTexture;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaCodecList;
import android.media.MediaFormat;
import android.os.Build;
import android.os.SystemClock;
import android.view.Surface;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Synchronous MediaCodec owned by the video worker. Surface changes are serialized with codec calls. */
final class HardwareVideo implements AutoCloseable {
    static final class Fault extends RuntimeException {
        final String stage, component;
        final int platformCode;
        Fault(String stage, String component, Throwable cause) {
            super(stage, cause);
            this.stage = stage;
            this.component = component == null ? "" : component;
            this.platformCode = cause instanceof MediaCodec.CodecException ?
                    ((MediaCodec.CodecException)cause).getErrorCode() : 0;
        }
    }

    private final PlaybackOutput owner;
    private final CodecCalls calls;
    private final String mime;
    private final int width, height, rotation, profile, level;
    private final float frameRate;
    private final NalAdapter nal;
    private final ByteBuffer rawConfig;
    private final List<String> names;
    private final MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
    private final Map<Long,Long> durations = new LinkedHashMap<>();
    private Surface desired, active, placeholder;
    private SurfaceTexture texture;
    private MediaCodec codec;
    private String name = "";
    private volatile Fault bindingFault;
    private boolean sawOutput, firstPacket = true, eos;
    private long firstQueuedMs, acquisitionMs, acquisitionBytes;
    int decodedWidth, decodedHeight;

    HardwareVideo(PlaybackOutput owner, TrackInfo track, Surface surface, ByteBuffer extra,
                  int ffProfile, int ffLevel, int bits, float fps, PlayerConfig policy) {
        this.owner = owner;
        calls = policy.codecCalls;
        width = track.width;
        height = track.height;
        rotation = track.rotationDegrees;
        frameRate = fps;
        desired = surface;
        switch (track.codec) {
            case "h264": mime = MediaFormat.MIMETYPE_VIDEO_AVC; break;
            case "hevc": mime = MediaFormat.MIMETYPE_VIDEO_HEVC; break;
            case "vp8": mime = MediaFormat.MIMETYPE_VIDEO_VP8; break;
            case "vp9": mime = MediaFormat.MIMETYPE_VIDEO_VP9; break;
            case "mpeg4": mime = MediaFormat.MIMETYPE_VIDEO_MPEG4; break;
            default: throw new Fault("hardwareMime", "", null);
        }
        boolean avc = mime.equals(MediaFormat.MIMETYPE_VIDEO_AVC);
        boolean hevc = mime.equals(MediaFormat.MIMETYPE_VIDEO_HEVC);
        profile = androidProfile(avc, hevc, ffProfile, bits);
        level = androidLevel(avc, hevc, ffLevel);
        nal = avc || hevc ? new NalAdapter(hevc, extra) : null;
        if (nal == null && extra != null && extra.hasRemaining()) {
            rawConfig = ByteBuffer.allocate(extra.remaining());
            rawConfig.put(extra.duplicate()).flip();
        } else rawConfig = null;
        names = candidates(policy);
        if (names.isEmpty()) throw new Fault("hardwareCapabilities", "", null);
    }

    private static int androidProfile(boolean avc, boolean hevc, int profile, int bits) {
        if (hevc) {
            if (profile == 2 || bits == 10) return MediaCodecInfo.CodecProfileLevel.HEVCProfileMain10;
            if (profile == 1) return MediaCodecInfo.CodecProfileLevel.HEVCProfileMain;
        }
        if (avc) switch (profile & 255) {
            case 66: return MediaCodecInfo.CodecProfileLevel.AVCProfileBaseline;
            case 77: return MediaCodecInfo.CodecProfileLevel.AVCProfileMain;
            case 88: return MediaCodecInfo.CodecProfileLevel.AVCProfileExtended;
            case 100: return MediaCodecInfo.CodecProfileLevel.AVCProfileHigh;
            case 110: return MediaCodecInfo.CodecProfileLevel.AVCProfileHigh10;
            case 122: return MediaCodecInfo.CodecProfileLevel.AVCProfileHigh422;
            case 244: return MediaCodecInfo.CodecProfileLevel.AVCProfileHigh444;
            default: break;
        }
        return 0;
    }

    private static int androidLevel(boolean avc, boolean hevc, int level) {
        int[] levels = avc ? new int[]{10,9,11,12,13,20,21,22,30,31,32,40,41,42,50,51,52,60,61,62} :
                new int[]{30,60,63,90,93,120,123,150,153,156,180,183,186};
        if (avc || hevc) for (int i = 0; i < levels.length; i++)
            if (levels[i] == level) return 1 << (avc ? i : 2*i);
        return 0;
    }

    private MediaFormat format() {
        MediaFormat f = MediaFormat.createVideoFormat(mime, width, height);
        if (profile != 0) f.setInteger(MediaFormat.KEY_PROFILE, profile);
        if (level != 0) f.setInteger(MediaFormat.KEY_LEVEL, level);
        if (frameRate > 0) f.setFloat(MediaFormat.KEY_FRAME_RATE, frameRate);
        return f;
    }

    private List<String> candidates(PlayerConfig policy) {
        List<String> selected = new ArrayList<>(2);
        for (MediaCodecInfo component : new MediaCodecList(MediaCodecList.REGULAR_CODECS).getCodecInfos()) {
            if (component.isEncoder() || selected.contains(component.getName())) continue;
            if (Build.VERSION.SDK_INT >= 29) {
                if (!component.isHardwareAccelerated() || component.isSoftwareOnly() || component.isAlias()) continue;
            } else if (!policy.verifiedLegacyCodecs.contains(component.getName())) continue;
            try {
                MediaCodecInfo.CodecCapabilities cap = component.getCapabilitiesForType(mime);
                if (cap.isFeatureRequired(MediaCodecInfo.CodecCapabilities.FEATURE_SecurePlayback) ||
                        cap.isFeatureRequired(MediaCodecInfo.CodecCapabilities.FEATURE_TunneledPlayback)) continue;
                MediaCodecInfo.VideoCapabilities vc = cap.getVideoCapabilities();
                if (vc == null || !vc.isSizeSupported(width, height) ||
                        (frameRate > 0 && !vc.areSizeAndRateSupported(width, height, frameRate)) ||
                        !cap.isFormatSupported(format())) continue;
                selected.add(component.getName());
                if (selected.size() == 2) break;
            } catch (IllegalArgumentException ignored) {
                // The component does not expose this MIME type.
            }
        }
        return selected;
    }

    private Surface target() {
        if (desired != null) return desired;
        if (placeholder == null) {
            texture = Build.VERSION.SDK_INT >= 26 ? new SurfaceTexture(false) : new SurfaceTexture(0);
            texture.setDefaultBufferSize(width, height);
            placeholder = new Surface(texture);
        }
        return placeholder;
    }

    synchronized void bind(Surface newSurface) {
        desired = newSurface;
        if (codec == null) return;
        try {
            Surface replacement = target();
            if (active != replacement) {
                codec.setOutputSurface(replacement);
                active = replacement;
            }
        } catch (RuntimeException failed) {
            bindingFault = new Fault("hardwareSurface", name, failed);
            releaseCodec();
        }
    }

    private void start() {
        MediaFormat f = format();
        f.setInteger(MediaFormat.KEY_ROTATION, rotation);
        f.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, NalAdapter.LIMIT);
        if (nal != null) {
            f.setByteBuffer("csd-0", nal.configuration(0));
            if (MediaFormat.MIMETYPE_VIDEO_AVC.equals(mime)) f.setByteBuffer("csd-1", nal.configuration(1));
        } else if (rawConfig != null) f.setByteBuffer("csd-0", rawConfig.duplicate());
        Fault last = null;
        for (String candidate : names) {
            String stage = "hardwareCreate";
            synchronized (this) {
                try {
                    name = candidate;
                    codec = calls.create(name);
                    stage = "hardwareConfigure";
                    active = target();
                    calls.configure(codec, f, active);
                    stage = "hardwareStart";
                    calls.start(codec);
                } catch (IOException | RuntimeException failure) {
                    last = new Fault(stage, name, failure);
                    releaseCodec();
                }
            }
            if (codec != null) {
                owner.backendSelected(name);
                return;
            }
            owner.backendFault(last);
        }
        throw last;
    }

    /** Input belongs to the caller until return. No packet data survives the JNI call. */
    void submit(ByteBuffer packet, long pts, long duration, boolean key) {
        if (bindingFault != null) throw bindingFault;
        if (codec == null) {
            if (acquisitionMs == 0) acquisitionMs = SystemClock.elapsedRealtime();
            acquisitionBytes += packet.remaining();
            if (acquisitionBytes > NalAdapter.LIMIT || SystemClock.elapsedRealtime() - acquisitionMs > 2000)
                throw new Fault("hardwareRandomAccess", name, null);
            if (nal != null) nal.collect(packet);
            if (!key || (nal != null && !nal.complete())) return;
            start();
        }
        if (pts == Long.MIN_VALUE) throw new Fault("hardwareTimestamp", name, null);
        queue(packet, pts, key, false);
        if (duration > 0) {
            if (durations.size() >= 256) durations.remove(durations.keySet().iterator().next());
            durations.put(pts, duration);
        }
        firstPacket = false;
        while (drainOne(0)) { /* drain all currently available output */ }
    }

    private void queue(ByteBuffer packet, long pts, boolean key, boolean end) {
        long began = SystemClock.elapsedRealtime();
        while (!owner.stopped()) {
            if (bindingFault != null) throw bindingFault;
            synchronized (this) {
                if (codec == null) throw new Fault("hardwareLost", name, null);
                int index = codec.dequeueInputBuffer(2000);
                if (index >= 0) {
                    int bytes = 0;
                    if (!end) {
                        ByteBuffer input = codec.getInputBuffer(index);
                        if (input == null) throw new Fault("hardwareInputBuffer", name, null);
                        input.clear();
                        if (nal != null) bytes = nal.copy(packet, input, firstPacket);
                        else {
                            bytes = packet.remaining();
                            if (bytes > NalAdapter.LIMIT || bytes > input.remaining())
                                throw new Fault("hardwareInputCapacity", name, null);
                            input.put(packet.duplicate());
                        }
                    }
                    calls.queue(codec, index, bytes, pts, end ? MediaCodec.BUFFER_FLAG_END_OF_STREAM :
                            key ? MediaCodec.BUFFER_FLAG_KEY_FRAME : 0);
                    if (firstQueuedMs == 0) firstQueuedMs = SystemClock.elapsedRealtime();
                    return;
                }
            }
            if (drainOne(0)) began = SystemClock.elapsedRealtime();
            if (SystemClock.elapsedRealtime() - began > 2000) throw new Fault("hardwareInputTimeout", name, null);
        }
        throw new Fault("hardwareCancelled", name, null);
    }

    private boolean drainOne(long timeoutUs) {
        int index;
        synchronized (this) {
            if (bindingFault != null) throw bindingFault;
            index = codec.dequeueOutputBuffer(info, timeoutUs);
            if (index == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                MediaFormat changed = codec.getOutputFormat();
                decodedWidth = changed.getInteger(MediaFormat.KEY_WIDTH);
                decodedHeight = changed.getInteger(MediaFormat.KEY_HEIGHT);
                codec.setVideoScalingMode(MediaCodec.VIDEO_SCALING_MODE_SCALE_TO_FIT);
                return true;
            }
        }
        if (index < 0) {
            if (!sawOutput && firstQueuedMs != 0 && SystemClock.elapsedRealtime() - firstQueuedMs > 2000)
                throw new Fault("hardwareFirstOutput", name, null);
            return index == MediaCodec.INFO_OUTPUT_BUFFERS_CHANGED;
        }
        eos = (info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0;
        boolean picture = (!eos || info.size > 0) && (info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0;
        long pts = info.presentationTimeUs;
        Long duration = durations.remove(pts);
        Surface selected = null;
        if (picture) {
            sawOutput = true;
            selected = owner.acquireVideo(pts, duration == null ? 0 : duration);
        }
        boolean submitted = false;
        try {
            synchronized (this) {
                if (bindingFault != null) throw bindingFault;
                if (selected != null && selected == active) {
                    codec.releaseOutputBuffer(index, System.nanoTime());
                    submitted = true;
                } else codec.releaseOutputBuffer(index, false);
            }
        } finally {
            if (selected != null) owner.finishVideo(pts, submitted);
        }
        return true;
    }

    void finish() {
        if (codec == null) throw new Fault("hardwareMissingConfiguration", name, null);
        queue(null, 0, false, true);
        long progress = SystemClock.elapsedRealtime();
        while (!eos && !owner.stopped()) {
            if (drainOne(5000)) progress = SystemClock.elapsedRealtime();
            else if (SystemClock.elapsedRealtime() - progress > 2000) throw new Fault("hardwareDrain", name, null);
        }
    }

    boolean started() { return firstQueuedMs != 0; }
    String component() { return name; }

    private void releaseCodec() {
        if (codec != null) {
            try { codec.release(); }
            finally { codec = null; active = null; }
        }
    }

    @Override public synchronized void close() {
        try { releaseCodec(); }
        finally {
            if (placeholder != null) { placeholder.release(); placeholder = null; }
            if (texture != null) { texture.release(); texture = null; }
            desired = null;
        }
    }
}
