package com.cn.media.playback;

import android.content.ContentResolver;
import android.os.CancellationSignal;
import java.io.IOException;

/** Coordinates cancellation with the single I/O owner, including provider/FD handoff. */
final class PlaybackSession {
    final long id;
    private final MediaSource source;
    private final InputRange admitted;
    private final CancellationSignal opening = new CancellationSignal();
    private boolean retiring;
    private NativeInput input;
    private PlaybackOutput current;

    PlaybackSession(long id, MediaSource source, InputRange admitted) {
        this.id = id;
        this.source = source;
        this.admitted = admitted;
    }

    /** I/O thread only. Any descriptor returned after cancellation is still closed here. */
    NativeInput acquire(ContentResolver resolver) throws IOException {
        try (InputRange range = admitted != null ? admitted : source.openDeferred(resolver, opening)) {
            synchronized (this) {
                if (retiring) return null;
                input = new NativeInput(range);
                return input;
            }
        }
    }

    synchronized void replace(PlaybackOutput output) {
        if (current != null) {
            current.stop();
            if (input != null) input.cancel();
        }
        current = output;
    }

    /** Called by the I/O owner after the previous epoch and all its workers have exited. */
    synchronized NativeInput enter(PlaybackOutput output) {
        if (retiring || current != output) return null;
        input.rearm();
        return input;
    }

    void retire() {
        synchronized (this) {
            retiring = true;
            if (current != null) current.stop();
            if (input != null) input.cancel();
        }
        opening.cancel();
    }

    /** I/O thread only, ordered after preparation and rendering. */
    synchronized void close() {
        if (input != null) { input.close(); input = null; }
        current = null;
    }
}
