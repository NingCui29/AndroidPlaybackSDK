package com.cn.media.playback;

/** Callbacks are serialized per player. Commands may be issued inside a callback. */
public interface PlayerListener {
    default void onSnapshot(PlayerSnapshot snapshot) {}
    default void onCommandResult(CommandResult result) {}
    default void onError(PlayerError error, PlayerSnapshot snapshot) {}
    default void onFirstAudioConsumption(PlayerSnapshot snapshot) {}
    default void onFirstVideoSubmission(PlayerSnapshot snapshot) {}
}
