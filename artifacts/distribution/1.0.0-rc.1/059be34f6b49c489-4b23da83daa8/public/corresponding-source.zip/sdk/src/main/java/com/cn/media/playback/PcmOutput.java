package com.cn.media.playback;

import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;
import android.os.SystemClock;
import java.nio.ByteBuffer;

/** Owned by the output worker. Native PCM buffers are borrowed only during write. */
final class PcmOutput implements AutoCloseable {
    private AudioTrack track;
    private int frameBytes, chunkBytes;
    private long written, lastHead, wraps;
    private boolean cancelled, paused;
    private float gain = 1f;

    synchronized int configure(int inputRate, int channels) {
        if (cancelled) return -1;
        int preferred = inputRate == 44100 ? 44100 : 48000;
        for (int rate : new int[]{preferred, preferred == 48000 ? 44100 : 48000}) {
            int mask = channels == 1 ? AudioFormat.CHANNEL_OUT_MONO : AudioFormat.CHANNEL_OUT_STEREO;
            int minimum = AudioTrack.getMinBufferSize(rate, mask, AudioFormat.ENCODING_PCM_16BIT);
            if (minimum <= 0) continue;
            frameBytes = channels * 2;
            int frames = Math.max((minimum + frameBytes - 1) / frameBytes, rate * 80 / 1000);
            try {
                track = new AudioTrack.Builder()
                        .setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                        .setAudioFormat(new AudioFormat.Builder().setSampleRate(rate).setChannelMask(mask)
                                .setEncoding(AudioFormat.ENCODING_PCM_16BIT).build())
                        .setBufferSizeInBytes(frames * frameBytes).setTransferMode(AudioTrack.MODE_STREAM).build();
                track.setVolume(gain);
                if (!paused) track.play();
                chunkBytes = rate / 100 * frameBytes;
                return rate;
            } catch (IllegalArgumentException | IllegalStateException e) {
                close();
            } catch (UnsupportedOperationException e) {
                close();
            }
        }
        return -1;
    }

    synchronized void cancel() {
        cancelled = true;
        if (track != null) {
            track.pause();
            track.flush();
        }
        notifyAll();
    }

    synchronized void setPaused(boolean pause) {
        if (paused == pause || cancelled) return;
        paused = pause;
        if (track != null) {
            if (pause) track.pause();
            else track.play();
        }
        notifyAll();
    }

    synchronized void setGain(float value) {
        gain = value;
        if (track != null && !cancelled) track.setVolume(value);
    }

    private void await(long ms) {
        try {
            wait(ms);
        } catch (InterruptedException interrupted) {
            Thread.currentThread().interrupt();
            cancelled = true;
        }
    }

    synchronized int write(ByteBuffer data) {
        long progress = SystemClock.elapsedRealtime();
        while (data.hasRemaining() && !cancelled) {
            if (paused) {
                await(0);
                progress = SystemClock.elapsedRealtime();
                continue;
            }
            int n = track.write(data, Math.min(chunkBytes, data.remaining()), AudioTrack.WRITE_NON_BLOCKING);
            if (n < 0 || n % frameBytes != 0) return -1;
            if (n == 0) {
                if (SystemClock.elapsedRealtime() - progress >= 500) return -1;
                await(2);
            } else {
                written += n / frameBytes;
                progress = SystemClock.elapsedRealtime();
            }
        }
        return cancelled ? -1 : 0;
    }

    synchronized long consumed() {
        if (track == null) return 0;
        long current = track.getPlaybackHeadPosition() & 0xffffffffL;
        if (current < lastHead) wraps++;
        lastHead = current;
        return (wraps << 32) + current;
    }

    synchronized long submitted() { return written; }

    synchronized long drain() {
        long previous = consumed(), progress = SystemClock.elapsedRealtime();
        // Some mixers stop requesting data below their end-of-stream threshold.
        // Silence can complete the final hardware burst; only content frames count.
        ByteBuffer tail = null;
        int paddingLeft = chunkBytes * 8;
        while (previous < written && !cancelled) {
            if (paused) {
                await(0);
                progress = SystemClock.elapsedRealtime();
                continue;
            }
            await(2);
            long now = consumed();
            if (now != previous) progress = SystemClock.elapsedRealtime();
            if (paddingLeft > 0 && SystemClock.elapsedRealtime() - progress >= 80) {
                if (tail == null) tail = ByteBuffer.allocateDirect(chunkBytes);
                tail.clear();
                int n = track.write(tail, Math.min(paddingLeft, chunkBytes), AudioTrack.WRITE_NON_BLOCKING);
                if (n < 0) return -1;
                paddingLeft -= n;
            }
            if (SystemClock.elapsedRealtime() - progress >= 2000) return -1;
            previous = now;
        }
        return cancelled ? -1 : written;
    }

    @Override public synchronized void close() {
        if (track != null) { track.release(); track = null; }
    }
}
