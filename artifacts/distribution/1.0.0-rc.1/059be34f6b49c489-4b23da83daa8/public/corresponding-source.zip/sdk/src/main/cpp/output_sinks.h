#pragma once
#include "decode_tracks.h"
#include <android/native_window_jni.h>
#include <libswresample/swresample.h>
#include <libswscale/swscale.h>
typedef struct AudioSink {
    JNIEnv *env;
    jobject output;
    jmethodID configure, write;
    SwrContext *swr;
    AVChannelLayout layout;
    int rate, format, channels;
} AudioSink;
typedef struct VideoSink {
    ANativeWindow *window;
    struct SwsContext *scale;
    int width, height, posted, cancel_fd;
} VideoSink;
int audio_deliver(void *opaque, const AVFrame *frame);
int audio_deliver_from(AudioSink *sink, const AVFrame *frame, int skip);
int audio_flush(AudioSink *s);
int video_post(void *opaque, const AVFrame *frame);
