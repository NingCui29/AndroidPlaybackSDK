#pragma once
#include <libavformat/avformat.h>

#define PLAYBACK_HW_INIT FFERRTAG('H','W','I','N')
#define PLAYBACK_HW_RUNTIME FFERRTAG('H','W','R','T')

// Single demux thread. Signal cancel_fd from the control thread, then join
// before destroying this object. Both descriptors are borrowed.
typedef struct PlaybackInput {
    int fd, cancel_fd, seekable;
    int64_t start, length, position, probe_remaining, deadline_us;
    AVIOContext *io;
    AVFormatContext *format;
} PlaybackInput;

int playback_probe(PlaybackInput *input);
void playback_close(PlaybackInput *input);
