-keep class com.cn.media.playback.NativeInput { native <methods>; }
-keepclassmembers class com.cn.media.playback.PcmOutput { int configure(int,int); int write(java.nio.ByteBuffer); }
-keep class com.cn.media.playback.TrackInfo { <init>(...); }
-keep class com.cn.media.playback.MediaInfo { <init>(...); }
-keepclassmembers class com.cn.media.playback.PlaybackOutput {
    int beginAudio(long);
    int configure(int,int);
    int write(java.nio.ByteBuffer);
    int endAudio();
    android.view.Surface acquireVideo(long,long);
    void finishVideo(long,boolean);
    int endVideo();
    void stop();
    int initHardware(int,int,int,float,java.nio.ByteBuffer);
    int hardwarePacket(java.nio.ByteBuffer,long,long,boolean);
    void softwareFallback();
    long positionMs();
    int videoUnavailable(int);
}
