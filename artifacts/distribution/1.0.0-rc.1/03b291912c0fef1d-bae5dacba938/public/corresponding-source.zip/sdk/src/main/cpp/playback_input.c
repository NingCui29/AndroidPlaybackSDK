#include "playback_input.h"
#include <errno.h>
#include <limits.h>
#include <poll.h>
#include <stdatomic.h>
#include <unistd.h>
#include <libavutil/time.h>

static atomic_int sequential_pollers;

int playback_sequential_pollers(void) {
    return atomic_load(&sequential_pollers);
}

static int interrupted(void *opaque) {
    PlaybackInput *in = opaque;
    struct pollfd cancel = {in->cancel_fd, POLLIN, 0};
    return poll(&cancel, 1, 0) > 0 ||
        (in->deadline_us && av_gettime_relative() >= in->deadline_us) ||
        (in->operation_deadline_us && av_gettime_relative() >= in->operation_deadline_us);
}

static int read_bytes(void *opaque, uint8_t *buffer, int count) {
    PlaybackInput *in = opaque;
    if (in->length >= 0) {
        int64_t left = in->length - in->position;
        if (!left) return AVERROR_EOF;
        if (count > left) count = (int)left;
    }
    if (in->probe_remaining == 0) return AVERROR(ENOBUFS);
    if (in->probe_remaining > 0 && count > in->probe_remaining)
        count = (int)in->probe_remaining;
    int64_t deadline = in->deadline_us ? in->deadline_us : av_gettime_relative() + 10000000;
    if (in->operation_deadline_us) deadline = FFMIN(deadline, in->operation_deadline_us);
    for (;;) {
        struct pollfd fds[] = {{in->fd, POLLIN, 0}, {in->cancel_fd, POLLIN, 0}};
        int64_t left = deadline - av_gettime_relative();
        if (left <= 0) return AVERROR(ETIMEDOUT);
        if (!in->seekable) atomic_fetch_add(&sequential_pollers, 1);
        int ready = poll(fds, 2, (int)((left + 999) / 1000));
        if (!in->seekable) atomic_fetch_sub(&sequential_pollers, 1);
        if (ready < 0 && errno == EINTR) continue;
        if (ready < 0) return AVERROR(errno);
        if (!ready) return AVERROR(ETIMEDOUT);
        if (fds[1].revents) return AVERROR_EXIT;
        ssize_t n = in->seekable ? pread(in->fd, buffer, count, in->start + in->position)
                                 : read(in->fd, buffer, count);
        if (n < 0 && (errno == EINTR || errno == EAGAIN)) continue;
        if (n < 0) return AVERROR(errno);
        if (!n) return AVERROR_EOF;
        in->position += n;
        if (in->probe_remaining >= 0) in->probe_remaining -= n;
        return (int)n;
    }
}

static int64_t seek_bytes(void *opaque, int64_t delta, int whence) {
    PlaybackInput *in = opaque;
    whence &= ~AVSEEK_FORCE;
    if (whence == AVSEEK_SIZE) return in->length >= 0 ? in->length : AVERROR(ENOSYS);
    if (!in->seekable) return AVERROR(ESPIPE);
    int64_t base;
    switch (whence) {
        case SEEK_SET: base = 0; break;
        case SEEK_CUR: base = in->position; break;
        case SEEK_END:
            if (in->length < 0) return AVERROR(ENOSYS);
            base = in->length; break;
        default: return AVERROR(EINVAL);
    }
    int64_t pos;
    if (__builtin_add_overflow(base, delta, &pos) || pos < 0 ||
        pos > INT64_MAX - in->start || (in->length >= 0 && pos > in->length))
        return AVERROR(EINVAL);
    return in->position = pos;
}

int playback_probe(PlaybackInput *in) {
    in->deadline_us = av_gettime_relative() + 5000000;
    in->probe_remaining = 5 * 1024 * 1024;
    uint8_t *buffer = av_malloc(32768);
    if (!buffer) return AVERROR(ENOMEM);
    in->io = avio_alloc_context(buffer, 32768, 0, in, read_bytes, NULL, seek_bytes);
    if (!in->io) { av_free(buffer); return AVERROR(ENOMEM); }
    in->io->seekable = in->seekable ? AVIO_SEEKABLE_NORMAL : 0;
    in->format = avformat_alloc_context();
    if (!in->format) return AVERROR(ENOMEM);
    in->format->pb = in->io;
    in->format->flags |= AVFMT_FLAG_CUSTOM_IO;
    in->format->probesize = in->probe_remaining;
    in->format->format_probesize = 512 * 1024;
    in->format->max_analyze_duration = 3000000;
    in->format->max_streams = 32;
    in->format->interrupt_callback = (AVIOInterruptCB){interrupted, in};
    int ret = avformat_open_input(&in->format, NULL, NULL, NULL);
    if (ret >= 0) ret = avformat_find_stream_info(in->format, NULL);
    in->deadline_us = 0;
    in->probe_remaining = -1;
    return ret;
}

void playback_close(PlaybackInput *in) {
    avformat_close_input(&in->format);
    if (in->io) av_freep(&in->io->buffer);
    avio_context_free(&in->io);
}
