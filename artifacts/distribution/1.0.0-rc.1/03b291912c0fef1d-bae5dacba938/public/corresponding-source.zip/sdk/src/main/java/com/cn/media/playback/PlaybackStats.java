package com.cn.media.playback;

import java.util.List;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/** Counters for the current playback timeline. Audio counts are interleaved sample frames. */
public final class PlaybackStats {
    public final long audioFramesWritten, audioFramesConsumed, videoFramesSubmitted, videoFramesDropped;
    public final long maxSubmissionGapMs;
    /** Time on SystemClock.elapsedRealtimeNanos(), zero until this timeline reaches that output. */
    public final long firstAudioConsumptionNs, firstVideoSubmissionNs;
    /** Latest submitted video timestamp minus the internal media clock, in microseconds. */
    public final long lastVideoOffsetUs;
    /** Active AudioTrack output, zero when unknown. Type uses AudioDeviceInfo constants. */
    public final int audioRouteId, audioRouteType, audioRouteChanges, audioOutputRebuilds;
    /** Input matrix/range selected by the software renderer for the latest submitted frame. */
    public final @NotNull String softwareColorMatrix, softwareColorRange;
    public final boolean softwareMatrixInferred, softwareRangeInferred;
    /** Largest referenced display frame plus SDK-owned conversion buffers in this epoch. */
    public final long softwarePeakFrameBytes;
    /** Latest geometry of the direct hardware output, null until MediaCodec reports its output format. */
    public final @Nullable HardwareOutputInfo hardwareOutput;
    /** Capability filters and ranked names for the most recent hardware configuration. */
    public final @NotNull List<String> hardwareSelection;
    public final @Nullable VideoRecoveryInfo videoRecovery;

    PlaybackStats(long written, long consumed, long submitted, long dropped, long gap, long offset,
                  int color, long peakBytes, int routeId, int routeType, int routeChanges, int rebuilds,
                  HardwareOutputInfo hardwareOutput, List<String> hardwareSelection, long firstAudioNs, long firstVideoNs,
                  VideoRecoveryInfo videoRecovery) {
        audioFramesWritten = written;
        audioFramesConsumed = consumed;
        videoFramesSubmitted = submitted;
        videoFramesDropped = dropped;
        maxSubmissionGapMs = gap;
        firstAudioConsumptionNs = firstAudioNs;
        firstVideoSubmissionNs = firstVideoNs;
        lastVideoOffsetUs = offset;
        audioRouteId = routeId;
        audioRouteType = routeType;
        audioRouteChanges = routeChanges;
        audioOutputRebuilds = rebuilds;
        switch (color & 255) {
            case 1: softwareColorMatrix = "BT.709"; break;
            case 4: softwareColorMatrix = "FCC"; break;
            case 5: softwareColorMatrix = "BT.601"; break;
            case 7: softwareColorMatrix = "SMPTE 240M"; break;
            case 9: softwareColorMatrix = "BT.2020 NCL"; break;
            default: softwareColorMatrix = "";
        }
        softwareColorRange = color == 0 ? "" : (color & 256) != 0 ? "full" : "limited";
        softwareMatrixInferred = (color & 1024) != 0;
        softwareRangeInferred = (color & 512) != 0;
        softwarePeakFrameBytes = peakBytes;
        this.hardwareOutput = hardwareOutput;
        this.hardwareSelection = hardwareSelection;
        this.videoRecovery = videoRecovery;
    }

    static final PlaybackStats EMPTY = new PlaybackStats(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, null,
            java.util.Collections.emptyList(), 0, 0, null);
}
