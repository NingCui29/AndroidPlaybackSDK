package com.cn.media.playback;

import org.jetbrains.annotations.NotNull;

/** A stable public failure category and a sanitized implementation detail. */
public final class PlayerError {
    public enum Code {
        INVALID_ARGUMENT(1001), INVALID_STATE(1002), SEEK_UNAVAILABLE(1003), TRACK_NOT_FOUND(1004),
        INPUT_PERMISSION(2001), INPUT_IO(2002), INPUT_TIMEOUT(2003),
        FORMAT_UNSUPPORTED(3001), TRACK_UNSUPPORTED(3002), INVALID_MEDIA_DATA(3003), NO_PLAYABLE_TRACK(3004),
        DECODER_INIT(4001), DECODER_RUNTIME(4002), OUTPUT_LOST(5001), RESOURCE_EXHAUSTED(5002);

        public final int number;
        Code(int number) { this.number = number; }

        static Code fromNumber(int number) {
            for (Code value : values()) if (value.number == number) return value;
            throw new IllegalArgumentException("Unknown internal error category");
        }
    }

    public enum Scope { REQUEST, TRACK, SESSION }

    public final @NotNull Code code;
    public final @NotNull Scope scope;
    public final long mediaId, timelineId, requestId;
    public final @NotNull String stage, backend;
    /** FFmpeg or platform numeric status when available, zero otherwise. */
    public final int nativeStatus;

    PlayerError(Code code, Scope scope, long mediaId, long timelineId, long requestId,
                String stage, String backend, int nativeStatus) {
        this.code = code;
        this.scope = scope;
        this.mediaId = mediaId;
        this.timelineId = timelineId;
        this.requestId = requestId;
        this.stage = stage;
        this.backend = backend;
        this.nativeStatus = nativeStatus;
    }
}
