package com.cn.media.playback;

import org.jetbrains.annotations.NotNull;

/** Timing of a hardware-to-software transition. Timestamps use SystemClock.elapsedRealtimeNanos(). */
public final class VideoRecoveryInfo {
    public final @NotNull String failureStage;
    public final long failureNanos, failurePositionUs, targetUs, firstSoftwarePtsUs, firstSoftwareSubmissionNanos;

    VideoRecoveryInfo(String stage, long failureNs, long at, long target, long firstPts, long firstNs) {
        failureStage = stage;
        failureNanos = failureNs; failurePositionUs = at; targetUs = target;
        firstSoftwarePtsUs = firstPts; firstSoftwareSubmissionNanos = firstNs;
    }
}
