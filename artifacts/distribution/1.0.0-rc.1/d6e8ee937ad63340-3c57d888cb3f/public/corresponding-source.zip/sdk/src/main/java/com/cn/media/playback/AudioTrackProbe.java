package com.cn.media.playback;

/** Owns a private pread cursor or a ref to the sequential source's packet history. */
final class AudioTrackProbe implements AutoCloseable {
    private long handle;

    AudioTrackProbe(long handle) { this.handle = handle; }
    static native long create(long source, int stream, long positionMs);
    private static native int inspect(long handle, long[] result);
    private static native void signal(long handle);
    private static native void destroy(long handle);

    // Only the preparation worker calls inspect/close. Control may wake it during any AVIO/packet wait.
    int inspect(long[] result) { return inspect(handle, result); }
    synchronized void cancel() { if (handle != 0) signal(handle); }
    @Override public synchronized void close() {
        if (handle != 0) { destroy(handle); handle = 0; }
    }
}
