package com.cn.media.playback;

import android.media.AudioAttributes;
import android.media.AudioDeviceInfo;
import android.media.AudioFormat;
import android.media.AudioTrack;
import android.os.SystemClock;
import java.nio.ByteBuffer;

/** Audio worker owns the track and stores unconsumed media in a bounded PCM ring. */
final class PcmOutput implements AutoCloseable {
    private final PcmCalls calls;
    private AudioTrack track;
    private ByteBuffer ring;
    private int rate, sourceRate, channels, frameBytes, highFrames, chunkFrames;
    private long queued, written, maxWritten, played, headBase, lastHead;
    private long lastHeadAt, lastWriteAt, nextRoutePoll;
    private int routeId, routeType, routeChanges, recoveries;
    private boolean cancelled, paused, invalidOutput;
    private float gain = 1f;

    PcmOutput() { this(new PcmCalls()); }
    PcmOutput(PcmCalls calls) { this.calls = calls; }

    synchronized int configure(int inputRate, int channels) {
        if (cancelled || (channels != 1 && channels != 2)) return -1;
        if (ring != null) return sourceRate == inputRate && this.channels == channels ? rate : -1;
        sourceRate = inputRate;
        this.channels = channels;
        frameBytes = channels * 2;
        int preferred = inputRate == 44100 ? 44100 : 48000;
        for (int choice : new int[]{preferred, preferred == 48000 ? 44100 : 48000}) {
            rate = choice;
            if (!openTrack()) continue;
            chunkFrames = rate / 100;
            highFrames = rate * 120 / 1000;
            ring = ByteBuffer.allocateDirect(highFrames * frameBytes);
            return rate;
        }
        return -1;
    }

    private boolean openTrack() {
        int mask = channels == 1 ? AudioFormat.CHANNEL_OUT_MONO : AudioFormat.CHANNEL_OUT_STEREO;
        int minimum = AudioTrack.getMinBufferSize(rate, mask, AudioFormat.ENCODING_PCM_16BIT);
        if (minimum <= 0) return false;
        int frames = Math.max((minimum + frameBytes - 1) / frameBytes, rate * 80 / 1000);
        try {
            track = new AudioTrack.Builder()
                    .setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                    .setAudioFormat(new AudioFormat.Builder().setSampleRate(rate).setChannelMask(mask)
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT).build())
                    .setBufferSizeInBytes(frames * frameBytes).setTransferMode(AudioTrack.MODE_STREAM).build();
            track.setVolume(gain);
            if (!paused) track.play();
            lastHeadAt = lastWriteAt = SystemClock.elapsedRealtime();
            nextRoutePoll = 0;
            return true;
        } catch (RuntimeException e) {
            releaseTrack();
            return false;
        }
    }

    private void releaseTrack() {
        if (track != null) { track.release(); track = null; }
    }

    synchronized void cancel() {
        cancelled = true;
        if (track != null) {
            try { track.pause(); track.flush(); } catch (IllegalStateException ignored) { }
        }
        notifyAll();
    }

    synchronized void setPaused(boolean pause) {
        if (paused == pause || cancelled) return;
        paused = pause;
        if (track != null) {
            try { if (pause) track.pause(); else track.play(); }
            catch (IllegalStateException broken) { invalidOutput = true; }
        }
        lastHeadAt = lastWriteAt = SystemClock.elapsedRealtime();
        notifyAll();
    }

    synchronized void setGain(float value) {
        gain = value;
        if (track != null && !cancelled) {
            try { track.setVolume(value); } catch (IllegalStateException broken) { invalidOutput = true; }
        }
    }

    private void await(long ms) {
        try { wait(ms); }
        catch (InterruptedException e) { Thread.currentThread().interrupt(); cancelled = true; }
    }

    synchronized long consumed() {
        if (track == null || cancelled || invalidOutput) return played;
        try {
            long raw = track.getPlaybackHeadPosition() & 0xffffffffL;
            if (raw < lastHead) {
                if (lastHead - raw > 0x80000000L) headBase += 0x100000000L;
                else { invalidOutput = true; return played; }
            }
            lastHead = raw;
            long now = SystemClock.elapsedRealtime();
            long progress = Math.min(written, headBase + raw);
            if (progress > played) { played = progress; lastHeadAt = now; }
            if (!paused && now >= nextRoutePoll) {
                AudioDeviceInfo device = track.getRoutedDevice();
                int id = device == null ? 0 : device.getId();
                if (id != routeId && routeId != 0 && id != 0) routeChanges++;
                routeId = id;
                routeType = device == null ? 0 : device.getType();
                nextRoutePoll = now + 100;
            }
        } catch (IllegalStateException broken) { invalidOutput = true; }
        return played;
    }

    synchronized long submitted() { return maxWritten; }
    synchronized long queuedFrames() { return queued; }
    synchronized int routeId() { return routeId; }
    synchronized int routeType() { return routeType; }
    synchronized int routeChanges() { return routeChanges; }
    synchronized int recoveries() { return recoveries; }

    private boolean recover(String cause) {
        android.util.Log.w("PlaybackPCM", "track=" + routeId + " rebuilds=" + recoveries + " reason=" + cause +
                " frames=" + played + "/" + written + "/" + queued);
        if (recoveries != 0 || cancelled) return false;
        recoveries++;
        releaseTrack();
        headBase = written = played;
        lastHead = 0;
        invalidOutput = false;
        return openTrack();
    }

    private int platformWrite(ByteBuffer buffer, int size) {
        try { return calls.write(track, buffer, size); }
        catch (IllegalStateException broken) { return AudioTrack.ERROR_INVALID_OPERATION; }
    }

    // Submit contiguous 10 ms slices. Ring bytes are retained until the playback head consumes them.
    private boolean pump() {
        consumed();
        long now = SystemClock.elapsedRealtime();
        if (invalidOutput) return recover("invalid head or route");
        if (written > played && now - lastHeadAt >= 1000) return recover("head stalled");
        while (written < queued) {
            int offset = (int)(written % highFrames);
            int frames = (int)Math.min(queued - written, Math.min(chunkFrames, highFrames - offset));
            ByteBuffer slice = ring.duplicate();
            slice.position(offset * frameBytes);
            int bytes = platformWrite(slice, frames * frameBytes);
            if (bytes < 0 || bytes % frameBytes != 0) return recover("write " + bytes);
            if (bytes == 0) return now - lastWriteAt < 500 || recover("write stalled");
            if (written == played) lastHeadAt = now;
            written += bytes / frameBytes;
            maxWritten = Math.max(maxWritten, written);
            lastWriteAt = now;
        }
        return true;
    }

    synchronized int write(ByteBuffer data) {
        if (ring == null || data.remaining() % frameBytes != 0) return -1;
        boolean throttled = false;
        while (data.hasRemaining() && !cancelled) {
            if (paused) { await(0); continue; }
            if (!pump()) return -1;
            long pending = queued - played;
            if (pending == highFrames) throttled = true;
            // A replacement mixer can require a full startup burst. Do not starve
            // it at the low-water mark when it accepted everything we offered.
            if (throttled && pending > highFrames / 2 &&
                    (pending >= highFrames || written < queued || SystemClock.elapsedRealtime() - lastHeadAt < 40)) {
                await(2);
                continue;
            }
            throttled = false;
            int offset = (int)(queued % highFrames);
            int frames = (int)Math.min(highFrames - pending,
                    Math.min(highFrames - offset, data.remaining() / frameBytes));
            ByteBuffer target = ring.duplicate();
            target.position(offset * frameBytes);
            int limit = data.limit();
            data.limit(data.position() + frames * frameBytes);
            target.put(data);
            data.limit(limit);
            if (written == queued) lastWriteAt = SystemClock.elapsedRealtime();
            queued += frames;
        }
        return !cancelled && pump() ? 0 : -1;
    }

    synchronized long drain() {
        if (ring == null) return 0;
        ByteBuffer tail = null;
        int padding = chunkFrames * frameBytes * 8;
        long progress = SystemClock.elapsedRealtime(), previous = consumed();
        while (played < queued && !cancelled) {
            if (paused) { await(0); progress = SystemClock.elapsedRealtime(); continue; }
            if (!pump()) return -1;
            long elapsed = SystemClock.elapsedRealtime();
            if (played != previous) { previous = played; progress = elapsed; }
            // Fill a hardware burst left below its mixer threshold, without increasing the media count.
            if (written == queued && padding > 0 && elapsed - progress >= 80) {
                if (tail == null) tail = ByteBuffer.allocateDirect(chunkFrames * frameBytes);
                tail.clear();
                int n = platformWrite(tail, Math.min(tail.capacity(), padding));
                if (n < 0) { if (!recover("tail write " + n)) return -1; }
                else padding -= n;
            }
            if (elapsed - progress >= 2000) return -1;
            if (played < queued) await(2);
        }
        return cancelled ? -1 : played;
    }

    @Override public synchronized void close() {
        releaseTrack();
        ring = null;
    }
}
