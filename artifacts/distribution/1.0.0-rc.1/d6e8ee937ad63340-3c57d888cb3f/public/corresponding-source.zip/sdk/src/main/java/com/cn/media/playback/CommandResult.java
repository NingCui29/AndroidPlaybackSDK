package com.cn.media.playback;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/** Exactly one terminal result for each accepted request. */
public final class CommandResult {
    public enum Status { SUCCESS, FAILED, CANCELLED, SUPERSEDED }
    public final long requestId;
    public final @NotNull Status status;
    public final @Nullable PlayerError error;
    public final @NotNull PlayerSnapshot snapshot;
    /** Source timestamp of the chosen preview frame or first surviving PCM, in milliseconds. */
    public final @Nullable Long actualPositionMs;

    CommandResult(long id, Status status, PlayerError error, PlayerSnapshot snapshot, Long actualPositionMs) {
        this.requestId = id;
        this.status = status;
        this.error = error;
        this.snapshot = snapshot;
        this.actualPositionMs = actualPositionMs;
    }
}
