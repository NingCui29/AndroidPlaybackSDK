package com.cn.media.playback;

/** Geometry reported by MediaCodec. Crop coordinates are inclusive and precede rotation. */
public final class HardwareOutputInfo {
    public final int width, height, cropLeft, cropTop, cropRight, cropBottom;
    public final int pixelAspectWidth, pixelAspectHeight, clockwiseRotation;
    public final int configurationVersion, outputFormatChanges, adaptiveChanges, codecRebuilds;
    public final String component;

    HardwareOutputInfo(String component, int width, int height, int left, int top, int right, int bottom,
                       int sarWidth, int sarHeight, int rotation, int version, int formats, int adaptive, int rebuilds) {
        this.component = component;
        this.width = width; this.height = height;
        cropLeft = left; cropTop = top; cropRight = right; cropBottom = bottom;
        pixelAspectWidth = sarWidth; pixelAspectHeight = sarHeight; clockwiseRotation = rotation;
        configurationVersion = version; outputFormatChanges = formats; adaptiveChanges = adaptive; codecRebuilds = rebuilds;
    }

    /** Width divided by height after the component's crop, pixel aspect correction and rotation. */
    public double displayAspectRatio() {
        double w = (cropRight - cropLeft + 1.0) * pixelAspectWidth / pixelAspectHeight;
        double h = cropBottom - cropTop + 1.0;
        double angle = Math.toRadians(clockwiseRotation);
        double c = Math.abs(Math.cos(angle)), s = Math.abs(Math.sin(angle));
        return (w*c + h*s) / (w*s + h*c);
    }
}
