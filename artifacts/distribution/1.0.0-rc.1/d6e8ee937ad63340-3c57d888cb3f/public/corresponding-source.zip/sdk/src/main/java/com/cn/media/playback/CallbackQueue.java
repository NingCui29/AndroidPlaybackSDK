package com.cn.media.playback;

import java.util.ArrayDeque;
import java.util.concurrent.Executor;

/** At most one drain runnable, including when the caller provides a thread pool. */
final class CallbackQueue {
    private static final class Entry {
        final boolean progress;
        final Runnable callback;
        Entry(boolean progress, Runnable callback) { this.progress = progress; this.callback = callback; }
    }
    private final Executor executor;
    private final ArrayDeque<Entry> queue = new ArrayDeque<>();
    private boolean draining;

    CallbackQueue(Executor executor) { this.executor = executor; }

    void add(boolean progress, Runnable callback) {
        synchronized (queue) {
            if (progress && !queue.isEmpty() && queue.getLast().progress) queue.removeLast();
            queue.addLast(new Entry(progress, callback));
            if (draining) return;
            draining = true;
        }
        executor.execute(this::drain);
    }

    private void drain() {
        for (;;) {
            Entry entry;
            synchronized (queue) {
                entry = queue.pollFirst();
                if (entry == null) { draining = false; return; }
            }
            try {
                entry.callback.run();
            } catch (RuntimeException failure) {
                android.util.Log.e("PlaybackSDK", "Listener failed: " + failure.getClass().getSimpleName());
            }
        }
    }
}
