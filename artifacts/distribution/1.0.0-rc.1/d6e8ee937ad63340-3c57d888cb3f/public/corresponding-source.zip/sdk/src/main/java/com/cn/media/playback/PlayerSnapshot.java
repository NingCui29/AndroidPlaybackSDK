package com.cn.media.playback;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/** Consistent state as of one control-queue revision. Times are milliseconds. */
public final class PlayerSnapshot {
    public enum State { IDLE, PREPARING, READY, PLAYING, PAUSED, ENDED, ERROR, STOPPING, RELEASING, RELEASED }

    public final long revision, mediaId, timelineId, positionMs;
    /** Changes when the host binds a different Surface or detaches its current one. */
    public final long surfaceVersion;
    /** SystemClock.elapsedRealtimeNanos() at the first submission on this binding and timeline, or zero. */
    public final long firstSurfaceSubmissionNs;
    public final @NotNull State state;
    public final boolean playWhenReady, seeking, muted;
    public final float volume;
    /** Null before preparation and after stop or release. */
    public final @Nullable MediaInfo media;
    /** Null when that stream type has no active track. */
    public final @Nullable TrackInfo audioTrack, videoTrack;
    /** Destination of a pending audio switch. The active track remains in audioTrack. */
    public final @Nullable TrackInfo pendingAudioTrack;
    public final @NotNull String videoBackend;
    public final @Nullable PlayerError error;
    /** Track failures recorded in this media session. Track identity is available in PlayerError.trackIndex. */
    public final @NotNull java.util.List<PlayerError> trackFailures;
    public final @NotNull PlaybackStats stats;

    PlayerSnapshot(long revision, long mediaId, long timelineId, State state, boolean playWhenReady,
                   boolean seeking, long positionMs, MediaInfo media, TrackInfo audio, TrackInfo video,
                   float volume, boolean muted, String videoBackend, PlayerError error, PlaybackStats stats,
                   TrackInfo pendingAudioTrack, long surfaceVersion, long firstSurfaceSubmissionNs,
                   java.util.List<PlayerError> trackFailures) {
        this.surfaceVersion = surfaceVersion;
        this.trackFailures = trackFailures;
        this.firstSurfaceSubmissionNs = firstSurfaceSubmissionNs;
        this.revision = revision;
        this.mediaId = mediaId;
        this.timelineId = timelineId;
        this.state = state;
        this.playWhenReady = playWhenReady;
        this.seeking = seeking;
        this.positionMs = positionMs;
        this.media = media;
        this.audioTrack = audio;
        this.pendingAudioTrack = pendingAudioTrack;
        this.videoTrack = video;
        this.volume = volume;
        this.muted = muted;
        this.videoBackend = videoBackend;
        this.error = error;
        this.stats = stats;
    }
}
