package com.cn.media.playback;

import android.media.AudioTrack;
import java.nio.ByteBuffer;

class PcmCalls {
    int write(AudioTrack track, ByteBuffer data, int bytes) {
        return track.write(data, bytes, AudioTrack.WRITE_NON_BLOCKING);
    }
}
