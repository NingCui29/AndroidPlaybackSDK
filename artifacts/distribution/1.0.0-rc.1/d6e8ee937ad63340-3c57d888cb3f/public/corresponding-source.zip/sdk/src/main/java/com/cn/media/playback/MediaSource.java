package com.cn.media.playback;

import org.jetbrains.annotations.NotNull;

import android.content.ContentResolver;
import android.content.res.AssetFileDescriptor;
import android.net.Uri;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;

import java.io.File;
import java.io.FileDescriptor;
import java.io.IOException;
import java.util.Objects;

/** An input description. Keep a supplied descriptor open until Player.open returns. */
public final class MediaSource {
    public static final long UNKNOWN_LENGTH = -1;
    private final File file;
    private final Uri uri;
    private final FileDescriptor descriptor;
    private final long offset;
    private final long length;

    private MediaSource(File file, Uri uri, FileDescriptor descriptor, long offset, long length) {
        this.file = file;
        this.uri = uri;
        this.descriptor = descriptor;
        this.offset = offset;
        this.length = length;
    }

    public static @NotNull MediaSource fromFile(@NotNull File file) {
        return new MediaSource(Objects.requireNonNull(file), null, null, 0, UNKNOWN_LENGTH);
    }

    public static @NotNull MediaSource fromUri(@NotNull Uri uri) {
        if (!ContentResolver.SCHEME_CONTENT.equals(Objects.requireNonNull(uri).getScheme())) {
            throw new IllegalArgumentException("Expected a content URI");
        }
        return new MediaSource(null, uri, null, 0, UNKNOWN_LENGTH);
    }

    public static @NotNull MediaSource fromDescriptor(@NotNull FileDescriptor descriptor, long offset, long length) {
        InputRange.validate(offset, length);
        return new MediaSource(null, null, Objects.requireNonNull(descriptor), offset, length);
    }

    // Run during synchronous command admission, before superseding the old session.
    boolean usesProvider() { return uri != null; }

    InputRange acquireDescriptor() throws IOException {
        return descriptor == null ? null :
                InputRange.take(ParcelFileDescriptor.dup(descriptor), offset, length);
    }

    // File/provider access is deferred to the preparation worker.
    InputRange openDeferred(ContentResolver resolver, CancellationSignal cancel) throws IOException {
        cancel.throwIfCanceled();
        if (file != null) {
            return InputRange.take(ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY),
                    0, UNKNOWN_LENGTH);
        }
        if (uri == null) throw new IllegalStateException("Descriptor must be acquired on admission");
        try (AssetFileDescriptor asset = resolver.openAssetFileDescriptor(uri, "r", cancel)) {
            cancel.throwIfCanceled();
            if (asset == null) throw new IOException("Provider returned no descriptor");
            return InputRange.take(ParcelFileDescriptor.dup(asset.getFileDescriptor()),
                    asset.getStartOffset(), asset.getDeclaredLength());
        }
    }
}
