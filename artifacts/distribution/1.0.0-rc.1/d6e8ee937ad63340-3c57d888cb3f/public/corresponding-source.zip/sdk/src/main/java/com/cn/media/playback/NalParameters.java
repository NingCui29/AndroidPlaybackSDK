package com.cn.media.playback;

/** Reads just the IDs and visible dimensions needed to identify an AVC/HEVC configuration. */
final class NalParameters {
    final int id, parent, width, height;
    final int profile, level, depth;
    final boolean highTier;

    private NalParameters(int id, int parent, int width, int height) {
        this(id, parent, width, height, 0, 0, 0, false);
    }

    private NalParameters(int id, int parent, int width, int height, int profile, int level, int depth, boolean tier) {
        this.id = id; this.parent = parent; this.width = width; this.height = height;
        this.profile = profile; this.level = level; this.depth = depth; this.highTier = tier;
    }

    static NalParameters read(byte[] set, boolean hevc, int type) {
        Bits b = new Bits(set, hevc ? 2 : 1);
        if (hevc && type == 32) return new NalParameters(b.bits(4), -1, 0, 0);
        if (type == (hevc ? 34 : 8)) return new NalParameters(b.ue(hevc ? 63 : 255), b.ue(hevc ? 15 : 31), 0, 0);
        return hevc ? hevcSps(b) : avcSps(b);
    }

    static int picturePps(byte[] header, boolean hevc) {
        Bits b = new Bits(header, hevc ? 2 : 1);
        if (hevc) {
            if (b.bits(1) == 0) return -1; // subsequent slice segment
            b.skip(1); // no_output_of_prior_pics_flag, present for IRAP
        } else {
            if (b.ue(Integer.MAX_VALUE) != 0) return -1;
            b.ue(9);
        }
        return b.ue(hevc ? 63 : 255);
    }

    private static NalParameters avcSps(Bits b) {
        int profile = b.bits(8);
        int constraints = b.bits(8), level = b.bits(8);
        if ((profile == 66 || profile == 77 || profile == 88) && level == 11 && (constraints & 16) != 0) level = 9;
        int id = b.ue(31), chroma = 1, depth = 8;
        switch (profile) {
            case 44: case 83: case 86: case 100: case 110: case 118: case 122:
            case 128: case 134: case 135: case 138: case 139: case 144: case 244:
                chroma = b.ue(3);
                boolean separate = chroma == 3 && b.bits(1) != 0;
                depth = 8 + b.ue(6); b.ue(6); b.skip(1);
                if (b.bits(1) != 0) {
                    int lists = chroma == 3 ? 12 : 8;
                    for (int i = 0; i < lists; i++) if (b.bits(1) != 0) {
                        int last = 8, next = 8;
                        for (int j = 0; j < (i < 6 ? 16 : 64); j++) {
                            if (next != 0) next = (last + b.se() + 256) & 255;
                            last = next == 0 ? last : next;
                        }
                    }
                }
                if (separate) chroma = 0;
                break;
            default: break;
        }
        b.ue(12);
        int poc = b.ue(2);
        if (poc == 0) b.ue(12);
        if (poc == 1) {
            b.skip(1); b.se(); b.se();
            int offsets = b.ue(255);
            for (int i = 0; i < offsets; i++) b.se();
        }
        b.ue(Integer.MAX_VALUE); b.skip(1);
        long width = 16L * (1L + b.ue(Integer.MAX_VALUE));
        long height = 16L * (1L + b.ue(Integer.MAX_VALUE));
        int frameOnly = b.bits(1);
        height *= 2 - frameOnly;
        if (frameOnly == 0) b.skip(1);
        b.skip(1);
        if (b.bits(1) != 0) {
            int unitX = chroma == 1 || chroma == 2 ? 2 : 1;
            int unitY = (chroma == 1 ? 2 : 1) * (2 - frameOnly);
            width -= unitX * ((long)b.ue(Integer.MAX_VALUE) + b.ue(Integer.MAX_VALUE));
            height -= unitY * ((long)b.ue(Integer.MAX_VALUE) + b.ue(Integer.MAX_VALUE));
        }
        return new NalParameters(id, -1, dimension(width), dimension(height), profile, level, depth, false);
    }

    private static NalParameters hevcSps(Bits b) {
        int vps = b.bits(4), layers = b.bits(3);
        b.skip(1 + 2);
        boolean highTier = b.bits(1) != 0;
        int profile = b.bits(5);
        b.skip(32 + 48);
        int level = b.bits(8);
        int profileFlags = 0, levelFlags = 0;
        for (int i = 0; i < layers; i++) {
            profileFlags |= b.bits(1) << i;
            levelFlags |= b.bits(1) << i;
        }
        if (layers > 0) b.skip(2 * (8 - layers));
        for (int i = 0; i < layers; i++) {
            if ((profileFlags & (1 << i)) != 0) b.skip(88);
            if ((levelFlags & (1 << i)) != 0) b.skip(8);
        }
        int id = b.ue(15), chroma = b.ue(3);
        if (chroma == 3 && b.bits(1) != 0) chroma = 0;
        long width = b.ue(Integer.MAX_VALUE), height = b.ue(Integer.MAX_VALUE);
        if (b.bits(1) != 0) {
            width -= (chroma == 1 || chroma == 2 ? 2 : 1) * ((long)b.ue(Integer.MAX_VALUE) + b.ue(Integer.MAX_VALUE));
            height -= (chroma == 1 ? 2 : 1) * ((long)b.ue(Integer.MAX_VALUE) + b.ue(Integer.MAX_VALUE));
        }
        int depth = 8 + b.ue(8);
        return new NalParameters(id, vps, dimension(width), dimension(height), profile, level, depth, highTier);
    }

    private static int dimension(long n) {
        if (n < 1 || n > Integer.MAX_VALUE) throw new IllegalArgumentException("Invalid coded dimensions");
        return (int)n;
    }

    private static final class Bits {
        final byte[] bytes;
        int next, zeros, octet, remaining;
        Bits(byte[] bytes, int start) { this.bytes = bytes; next = start; }
        int bits(int count) {
            int value = 0;
            for (int i = 0; i < count; i++) {
                if (remaining == 0) {
                    if (zeros == 2 && next < bytes.length && bytes[next] == 3) { next++; zeros = 0; }
                    if (next >= bytes.length) throw new IllegalArgumentException("Truncated parameter set");
                    octet = bytes[next++] & 255;
                    zeros = octet == 0 ? Math.min(2, zeros + 1) : 0;
                    remaining = 8;
                }
                value = (value << 1) | ((octet >>> (--remaining)) & 1);
            }
            return value;
        }
        void skip(int count) { bits(count); }
        int ue(int max) {
            int leading = 0;
            while (bits(1) == 0) if (++leading > 30) throw new IllegalArgumentException("Parameter value too large");
            long value = (1L << leading) - 1 + bits(leading);
            if (value > max) throw new IllegalArgumentException("Parameter value out of range");
            return (int)value;
        }
        int se() { int n = ue(Integer.MAX_VALUE); return (n & 1) == 0 ? -(n / 2) : n / 2 + 1; }
    }
}
