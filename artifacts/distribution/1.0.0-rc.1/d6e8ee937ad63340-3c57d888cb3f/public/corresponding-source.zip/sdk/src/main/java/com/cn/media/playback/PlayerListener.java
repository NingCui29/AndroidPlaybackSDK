package com.cn.media.playback;

import org.jetbrains.annotations.NotNull;

/** Callbacks are serialized per player. Commands may be issued inside a callback. */
public interface PlayerListener {
    default void onSnapshot(@NotNull PlayerSnapshot snapshot) {}
    default void onCommandResult(@NotNull CommandResult result) {}
    default void onError(@NotNull PlayerError error, @NotNull PlayerSnapshot snapshot) {}
    default void onFirstAudioConsumption(@NotNull PlayerSnapshot snapshot) {}
    default void onFirstVideoSubmission(@NotNull PlayerSnapshot snapshot) {}
}
