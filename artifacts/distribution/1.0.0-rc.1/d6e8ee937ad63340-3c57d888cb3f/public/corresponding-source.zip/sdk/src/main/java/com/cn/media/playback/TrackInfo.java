package com.cn.media.playback;

import org.jetbrains.annotations.NotNull;

/** Immutable stream description. Its identity belongs to the media session that issued it. */
public final class TrackInfo {
    public enum Type { AUDIO, VIDEO, SUBTITLE, OTHER }
    public final long mediaId;
    public final int index;
    public final @NotNull Type type;
    public final @NotNull String codec;
    public final @NotNull String language;
    /** Sanitized UTF-8 stream title, empty when absent. */
    public final @NotNull String title;
    /** FFmpeg timestamps use timeBaseNumerator / timeBaseDenominator seconds per tick. */
    public final int timeBaseNumerator, timeBaseDenominator;
    /** Pixel aspect ratio; a zero numerator indicates unspecified geometry. */
    public final int pixelAspectNumerator, pixelAspectDenominator;
    public final int codecInitializationBytes;
    public final boolean defaultTrack, coverArt, softwareDecodable;
    public final int width, height, sampleRate, channels, rotationDegrees;

    TrackInfo(long mediaId, int index, int type, String codec, String language, boolean defaultTrack,
              boolean coverArt, boolean softwareDecodable, int width, int height, int sampleRate, int channels, int rotation,
              byte[] titleUtf8, int timeNum, int timeDen, int aspectNum, int aspectDen, int initBytes) {
        this.mediaId = mediaId;
        this.index = index;
        this.type = Type.values()[type];
        this.codec = codec;
        this.language = language;
        this.title = new String(titleUtf8, java.nio.charset.StandardCharsets.UTF_8).replaceAll("\\p{Cntrl}", "");
        timeBaseNumerator = timeNum;
        timeBaseDenominator = timeDen;
        pixelAspectNumerator = aspectNum;
        pixelAspectDenominator = aspectDen;
        codecInitializationBytes = initBytes;
        this.defaultTrack = defaultTrack;
        this.coverArt = coverArt;
        this.softwareDecodable = softwareDecodable;
        this.width = width;
        this.height = height;
        this.sampleRate = sampleRate;
        this.channels = channels;
        this.rotationDegrees = rotation;
    }
}
