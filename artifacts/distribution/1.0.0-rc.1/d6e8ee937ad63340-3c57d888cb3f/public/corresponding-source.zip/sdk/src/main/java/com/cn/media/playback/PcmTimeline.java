package com.cn.media.playback;

import java.util.ArrayDeque;

/** Maps unique media PCM frames, including queued frames retained for an AudioTrack rebuild. */
final class PcmTimeline {
    private static final class Segment {
        final long startFrame, ptsUs;
        Segment(long startFrame, long ptsUs) { this.startFrame = startFrame; this.ptsUs = ptsUs; }
    }
    private final ArrayDeque<Segment> pending = new ArrayDeque<>();
    private long currentFrame, currentPts, firstPts, inheritedShift;
    int jumps;

    void start(long ptsUs, long previousShift) {
        pending.clear();
        currentFrame = 0;
        currentPts = firstPts = ptsUs;
        inheritedShift = previousShift;
    }

    void append(long queuedFrames, long ptsUs) {
        if (!pending.isEmpty() && pending.getLast().startFrame == queuedFrames) pending.removeLast();
        pending.add(new Segment(queuedFrames, ptsUs));
    }

    long mediaUs(long consumed, int rate) {
        while (!pending.isEmpty() && consumed > pending.getFirst().startFrame) {
            Segment segment = pending.removeFirst();
            currentFrame = segment.startFrame;
            currentPts = segment.ptsUs;
            jumps++;
        }
        return currentPts + timeUs(consumed - currentFrame, rate);
    }

    // Subtract this offset for scheduling on continuous, consumed PCM time.
    long shiftUs(int rate) {
        return inheritedShift + currentPts - firstPts - timeUs(currentFrame, rate);
    }

    private static long timeUs(long frames, int rate) {
        return frames / rate * 1000000L + (frames % rate) * 1000000L / rate;
    }
}
