package com.cn.media.playback;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/** A snapshot of the input after successful probing. Unknown duration is null. */
public final class MediaInfo {
    public final long mediaId;
    public final @Nullable Long durationMs;
    public final @NotNull List<TrackInfo> tracks;
    public final boolean seekable;
    /** Bytes obtained from the input during probing. Replaying a buffered prefix is excluded. */
    public final long probeBytes;
    public enum ProbeLimit { NONE, BYTES, WALL_TIME }
    public final @NotNull ProbeLimit probeLimit;
    MediaInfo(long mediaId, long durationMs, boolean seekable, TrackInfo[] tracks, long probeBytes, int limit) {
        this.probeBytes = probeBytes;
        this.probeLimit = ProbeLimit.values()[limit];
        this.mediaId = mediaId;
        this.seekable = seekable;
        this.durationMs = durationMs < 0 ? null : durationMs;
        this.tracks = Collections.unmodifiableList(Arrays.asList(tracks.clone()));
    }
}
