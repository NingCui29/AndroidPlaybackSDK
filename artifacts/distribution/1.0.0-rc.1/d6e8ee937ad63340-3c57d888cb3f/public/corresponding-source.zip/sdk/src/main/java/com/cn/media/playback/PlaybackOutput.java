package com.cn.media.playback;

import android.os.SystemClock;
import android.view.Surface;
import java.nio.ByteBuffer;

/** One rendering epoch. Decode workers enter via JNI; the control queue owns user intent. */
final class PlaybackOutput implements AutoCloseable {
    interface Observer {
        void ready(PlaybackOutput output, long actualMs);
        void firstAudio(PlaybackOutput output);
        void firstVideo(PlaybackOutput output);
        void backend(PlaybackOutput output, String name);
        void backendFault(PlaybackOutput output, HardwareVideo.Fault failure);
        void surfaceLost(PlaybackOutput output, Surface invalid);
        void trackLost(PlaybackOutput output, boolean isVideo, int reason);
        void audioSwitchResult(PlaybackOutput output, long request, int raw, long actualMs);
    }

    private final Observer observer;
    private PcmOutput pcm, framePcm;
    private int audioIndex;
    private long switchRequest, switchFloor, audioVersion, previousWritten, previousConsumed;
    private float gain;
    private boolean audio;
    private boolean video;
    private boolean paused, stopped, preview, ready, firstAudio, firstVideo, videoBusy, audioEnded;
    private Surface surface;
    private Surface cpuSurface;
    private boolean switching;
    private final long targetUs;
    private final TrackInfo videoTrack;
    private final PlayerConfig policy;
    private final boolean forceSoftware;
    private volatile HardwareVideo hardware;
    private volatile HardwareVideo.Fault lastFault;
    private volatile String backend;
    private int rate;
    private long audioAnchor = -1, clockAnchor, wallAnchor, lastVideo = -1, intervalUs = 33000;
    private long nextVideo = -1, frozenUs;
    private final PcmTimeline pcmTimeline = new PcmTimeline();
    private long audioShiftUs, videoShiftUs;
    private boolean videoJumped;
    private long submitted, dropped, lastSubmissionNs, maxGapNs, lastOffsetUs;
    private long firstAudioNs, firstVideoNs;
    private int softwareColor;
    private long softwarePeakBytes;
    private volatile HardwareOutputInfo hardwareFormat;
    private VideoRecoveryInfo recovery;
    private volatile java.util.List<String> hardwareSelection = java.util.Collections.emptyList();
    private PlaybackStats finalStats;
    private final long[] recentIntervals = new long[5];
    private int intervalCount, intervalIndex;

    PlaybackOutput(Observer observer, int audioIndex, TrackInfo videoTrack, long targetMs,
                   boolean preview, boolean playing, Surface surface, float gain, PlayerConfig policy,
                   boolean forceSoftware) {
        this.observer = observer;
        pcm = new PcmOutput(policy.pcmCalls);
        this.audioIndex = audioIndex;
        this.audio = audioIndex >= 0;
        this.gain = gain;
        switchFloor = targetMs * 1000;
        this.videoTrack = videoTrack;
        this.video = videoTrack != null;
        this.policy = policy;
        this.forceSoftware = forceSoftware;
        backend = video && (forceSoftware || policy.videoMode == PlayerConfig.VideoMode.SOFTWARE_ONLY) ? "ffmpeg" : "";
        this.targetUs = targetMs * 1000;
        this.preview = preview;
        this.surface = surface;
        paused = !playing;
        clockAnchor = frozenUs = targetUs;
        wallAnchor = nowUs();
        pcm.setGain(gain);
        pcm.setPaused(paused);
    }

    private static long nowUs() { return SystemClock.elapsedRealtimeNanos() / 1000; }

    private void waitForChange(long ms) {
        try { wait(ms); }
        catch (InterruptedException e) { Thread.currentThread().interrupt(); stop(); }
    }

    synchronized void setPlaying(boolean playing) {
        if (playing == !paused || stopped) return;
        frozenUs = clockUs();
        paused = !playing;
        lastSubmissionNs = 0;
        if (hardware != null) hardware.resetOutputWait();
        clockAnchor = frozenUs;
        wallAnchor = nowUs();
        pcm.setPaused(paused);
        notifyAll();
    }

    synchronized void setGain(float gain) { this.gain = gain; pcm.setGain(gain); }

    synchronized int selectedAudioIndex() { return audioIndex; }
    synchronized long selectedAudioFloorUs() { return switchFloor; }
    synchronized long audioSelectionVersion() { return audioVersion; }

    synchronized boolean installAudio(int index, long request, PcmOutput replacement) {
        if (stopped || audioEnded) return false;
        switchFloor = clockUs();
        previousWritten += pcm.submitted();
        previousConsumed += pcm.consumed();
        // cancel() holds the old PCM monitor and flushes it before publication.
        // A writer already inside JNI keeps framePcm, never the new output.
        pcm.cancel();
        pcm.close();
        pcm = replacement;
        pcm.setGain(gain);
        pcm.setPaused(paused);
        audio = true;
        audioIndex = index;
        audioVersion++;
        switchRequest = request;
        audioAnchor = -1;
        firstAudio = false;
        clockAnchor = frozenUs = switchFloor;
        wallAnchor = nowUs();
        notifyAll();
        return true;
    }

    synchronized void forgetAudioRequest(long request) {
        if (switchRequest == request) switchRequest = 0;
    }

    synchronized int switchingAudioFailed(int index, int raw) {
        if (index != audioIndex) return 1;
        if (switchRequest == 0) return 0;
        long request = switchRequest;
        switchRequest = 0;
        abandonAudio(index);
        observer.audioSwitchResult(this, request, raw, frozenUs / 1000);
        notifyAll();
        return 1;
    }

    synchronized void abandonAudio(int index) {
        if (audioIndex != index) return;
        frozenUs = clockAnchor = clockUs();
        wallAnchor = nowUs();
        pcm.cancel();
        audioIndex = -1;
        audio = false;
        notifyAll();
    }

    private void acceptSwitchedAudio() {
        if (switchRequest != 0 && framePcm == pcm) {
            long request = switchRequest;
            switchRequest = 0;
            observer.audioSwitchResult(this, request, 0, audioAnchor / 1000);
        }
    }

    synchronized void bind(Surface replacement) {
        if (stopped || surface == replacement) return;
        if (!audio && replacement == null) frozenUs = clockUs();
        switching = true;
        awaitSurfaceIdle();
        if (stopped) {
            switching = false;
            notifyAll();
            return;
        }
        releaseCpuSurface();
        firstOnSurface = 0;
        lastSubmissionNs = 0;
        surface = replacement;
        if (hardware != null) { hardware.bind(replacement); hardware.resetOutputWait(); }
        if (!audio && replacement != null) {
            clockAnchor = frozenUs;
            wallAnchor = nowUs();
        }
        switching = false;
        notifyAll();
    }

    synchronized void stop() {
        if (!stopped) {
            frozenUs = clockUs();
            stopped = true;
            pcm.cancel();
            notifyAll();
        }
        // A replacement epoch can become current before its predecessor finishes
        // joining. No old Surface write may survive that handoff.
        awaitSurfaceIdle();
        // A worker between candidate discovery and codec.configure may still hold
        // this decoder. close() fences configuration even after this epoch retires.
        if (hardware != null) hardware.close();
        releaseCpuSurface();
        surface = null;
    }

    private void awaitSurfaceIdle() {
        boolean interrupted = false;
        long start = videoBusy ? SystemClock.elapsedRealtimeNanos() : 0;
        while (videoBusy) {
            try { wait(); }
            catch (InterruptedException e) { interrupted = true; }
        }
        if (start != 0) {
            long waitedMs = (SystemClock.elapsedRealtimeNanos() - start) / 1_000_000;
            if (waitedMs > 100) android.util.Log.w("PlaybackSurface", "In-flight " + backend + " access took " + waitedMs + " ms");
        }
        if (interrupted) Thread.currentThread().interrupt();
    }

    synchronized boolean stopped() { return stopped; }
    synchronized boolean expectsVideoProgress() { return !stopped && (!paused || preview) && surface != null; }

    String backend() { return backend; }
    void backendSelected(String name) {
        backend = name;
        observer.backend(this, name);
    }
    synchronized void backendFault(HardwareVideo.Fault fault) {
        if (lastFault == fault) return;
        fault.failedAtNs = SystemClock.elapsedRealtimeNanos();
        fault.positionUs = clockUs();
        lastFault = fault;
        observer.backendFault(this, fault);
    }
    boolean surfaceSwitchFailed() { return lastFault != null && "hardwareSurface".equals(lastFault.stage); }
    HardwareVideo.Fault hardwareFailure() { return lastFault; }

    synchronized int initHardware(int profile, int level, int depth, float fps, ByteBuffer extra) {
        if (stopped) return -3;
        detachInvalidSurface();
        if (forceSoftware || policy.videoMode == PlayerConfig.VideoMode.SOFTWARE_ONLY) return 0;
        try {
            hardware = new HardwareVideo(this, videoTrack, surface, extra, profile, level, depth, fps, policy);
            return 1;
        } catch (RuntimeException failure) {
            int outcome = hardwareError(failure, "hardwareSetup");
            if (outcome < 0) return outcome;
            softwareFallback();
            return 0;
        }
    }

    // 0 = accepted, 1 = try software before hardware accepted data,
    // 2 = recover from the current position, negative = terminal or cancellation.
    int hardwarePacket(ByteBuffer packet, long ptsUs, long durationUs, boolean key, ByteBuffer extra) {
        try {
            if (packet == null) hardware.finish();
            else hardware.submit(packet, ptsUs, durationUs, key, extra);
            return stopped() ? -3 : 0;
        } catch (RuntimeException failure) {
            return hardwareError(failure, "hardwareDecode");
        }
    }

    int flushHardwarePicture() {
        try {
            if (hardware != null) hardware.beforeInputWait();
            return 0;
        } catch (RuntimeException failure) { return hardwareError(failure, "hardwareOutput"); }
    }

    int configurationWaitMs() { return hardware == null ? -1 : hardware.configurationWaitMs(); }

    void hardwareFormat(HardwareOutputInfo changed) { hardwareFormat = changed; }

    void hardwareSelection(java.util.List<String> trace) {
        hardwareSelection = java.util.Collections.unmodifiableList(new java.util.ArrayList<>(trace));
    }

    private synchronized int hardwareError(RuntimeException failure, String stage) {
        if (stopped) return -3;
        HardwareVideo decoder = hardware;
        boolean runtime = decoder != null && decoder.started();
        HardwareVideo.Fault fault = failure instanceof HardwareVideo.Fault ?
                (HardwareVideo.Fault)failure : new HardwareVideo.Fault(stage, decoder == null ? "" : decoder.component(), failure);
        fault.runtime = runtime;
        backendFault(fault);
        if (decoder != null) decoder.close();
        hardware = null;
        if (policy.videoMode == PlayerConfig.VideoMode.HARDWARE_ONLY) {
            if (fault.code() == PlayerError.Code.RESOURCE_EXHAUSTED) return -4;
            if (fault.code() == PlayerError.Code.INVALID_MEDIA_DATA) return -5;
            return runtime ? -2 : -1;
        }
        return runtime ? 2 : 1;
    }

    synchronized void recoveryFrom(HardwareVideo.Fault fault, long target) {
        if (fault != null) recovery = new VideoRecoveryInfo(fault.stage, fault.failedAtNs, fault.positionUs, target, -1, 0);
    }

    synchronized void softwareFallback() {
        recoveryFrom(lastFault, clockUs());
        firstVideo = false;
        backendSelected("ffmpeg");
    }

    synchronized int trackUnavailable(boolean isVideo, int reason) {
        if (stopped) return 0;
        if (policy.requireAllSelectedTracks || (isVideo && policy.videoMode == PlayerConfig.VideoMode.HARDWARE_ONLY)) {
            observer.trackLost(this, isVideo, reason);
            return 0;
        }
        if (isVideo) {
            video = false;
            backend = "";
        } else {
            frozenUs = clockAnchor = clockUs();
            wallAnchor = nowUs();
            audio = false;
            pcm.cancel();
        }
        observer.trackLost(this, isVideo, reason);
        if (audio && audioAnchor >= 0) signalReady(audioAnchor);
        notifyAll();
        return audio || video ? 1 : 2;
    }

    private long clockUs() {
        if (stopped || paused || (!audio && surface == null)) return frozenUs;
        if (audio && !audioEnded && audioAnchor >= 0 && rate > 0) {
            long consumed = pcm.consumed();
            if (consumed > 0 && !firstAudio) {
                firstAudio = true;
                if (firstAudioNs == 0) firstAudioNs = SystemClock.elapsedRealtimeNanos();
                if (!video || surface == null) signalReady(audioAnchor);
                observer.firstAudio(this);
            }
            long position = pcmTimeline.mediaUs(consumed, rate);
            audioShiftUs = pcmTimeline.shiftUs(rate);
            return position;
        }
        if (lastVideo < 0 && !audioEnded) return frozenUs;
        return clockAnchor + Math.max(0, nowUs() - wallAnchor);
    }

    synchronized long positionMs() { return Math.max(0, clockUs() / 1000); }

    private long videoAheadUs(long pts) {
        long clock = clockUs();
        return audio ? (pts - videoShiftUs) - (clock - audioShiftUs) : pts - clock;
    }

    synchronized PlaybackStats statistics() {
        if (finalStats != null) return finalStats;
        long written = pcm.submitted();
        return new PlaybackStats(previousWritten + written, previousConsumed + Math.min(written, pcm.consumed()), submitted, dropped,
                maxGapNs / 1000000, lastOffsetUs, softwareColor, softwarePeakBytes,
                pcm.routeId(), pcm.routeType(), pcm.routeChanges(), pcm.recoveries(), hardwareFormat, hardwareSelection,
                firstAudioNs, firstVideoNs, recovery, pcmTimeline.jumps);
    }

    synchronized void softwareVideoInfo(int color, long peakBytes) {
        softwareColor = color;
        softwarePeakBytes = peakBytes;
    }

    private void signalReady(long ptsUs) {
        if (ready) return;
        ready = true;
        observer.ready(this, Math.max(0, ptsUs / 1000));
    }

    // Called only for audio frames surviving preroll.
    synchronized int beginAudio(int stream, long ptsUs, boolean discontinuity) {
        if (audioIndex != stream) return 1;
        framePcm = pcm;
        if (audioAnchor < 0) {
            audioAnchor = ptsUs >= 0 ? ptsUs : targetUs;
            pcmTimeline.start(audioAnchor, audioShiftUs);
        } else if (discontinuity) {
            pcmTimeline.append(pcm.queuedFrames(), ptsUs);
        }
        if (paused && (!video || surface == null)) signalReady(audioAnchor);
        notifyAll();
        return stopped ? -1 : 0;
    }

    synchronized int configure(int inputRate, int channels) {
        if (stopped) return -1;
        if (framePcm != pcm) return inputRate;
        rate = pcm.configure(inputRate, channels);
        notifyAll();
        return rate;
    }

    int write(ByteBuffer samples) {
        PcmOutput writer;
        synchronized (this) {
            writer = framePcm;
            if (writer != pcm) return 0;
            if (switchRequest != 0 && !policy.audioSwitchCalls.firstWrite(audioIndex)) return -1;
            // Paused handoff establishes a validated PCM buffer before its first audible write.
            if (paused) acceptSwitchedAudio();
        }
        int status = writer.write(samples);
        synchronized (this) {
            if (writer != pcm) return 0;
            if (status >= 0 && !stopped) {
                acceptSwitchedAudio();
                clockUs();
            }
            notifyAll();
        }
        return status;
    }

    int endAudio() {
        long consumed = pcm.drain();
        synchronized (this) {
            if (consumed < 0 || stopped) return -1;
            clockAnchor = frozenUs = clockUs();
            wallAnchor = nowUs();
            audioEnded = true;
            notifyAll();
            return 0;
        }
    }

    private void updateInterval(long pts, long durationUs) {
        if (lastVideo >= 0 && pts > lastVideo && pts - lastVideo <= 500000) {
            recentIntervals[intervalIndex] = pts - lastVideo;
            intervalIndex = (intervalIndex + 1) % recentIntervals.length;
            intervalCount = Math.min(intervalCount + 1, recentIntervals.length);
        }
        if (durationUs > 0) intervalUs = durationUs;
        else if (intervalCount > 0) {
            long[] ordered = java.util.Arrays.copyOf(recentIntervals, intervalCount);
            java.util.Arrays.sort(ordered);
            intervalUs = ordered[ordered.length / 2];
        }
    }

    // A first call with no successor only classifies a potential late frame.
    // On the second call a newer decoded frame exists and the clock is checked again.
    synchronized int lateVideo(long pts, long durationUs, long newer) {
        if (!firstVideo || paused || preview || switching || stopped || surface == null ||
                pts < 0 || nextVideo < 0 || Math.abs(pts - nextVideo) > 500000) return 0;
        long duration = durationUs > 0 ? durationUs : intervalUs;
        long threshold = Math.max(50000L, Math.min(Long.MAX_VALUE / 2, duration) * 2);
        if (videoAheadUs(pts) >= -threshold) return 0;
        if (newer == Long.MIN_VALUE) return 1;
        if (newer <= pts || Math.abs(newer - pts - duration) > 500000) return 0;
        updateInterval(pts, durationUs);
        lastVideo = pts;
        nextVideo = pts + intervalUs;
        dropped++;
        return 1;
    }

    // The native worker must pair each non-null return with finishVideo after releasing its window.
    synchronized Surface acquireVideo(long ptsUs, long durationUs) {
        long pts = ptsUs >= 0 ? ptsUs : nextVideo >= 0 ? nextVideo : targetUs;
        updateInterval(pts, durationUs);
        if (lastVideo < 0 && pts + intervalUs <= targetUs) return null;
        boolean reset = lastVideo < 0 || (nextVideo >= 0 && Math.abs(pts - nextVideo) > 500000);
        if (reset && lastVideo >= 0) {
            videoShiftUs += pts - nextVideo;
            videoJumped = true;
        }
        lastVideo = pts;
        nextVideo = pts + intervalUs;
        if (reset && (audioAnchor < 0 || !audio)) {
            clockAnchor = firstVideo ? pts : Math.max(targetUs, pts);
            wallAnchor = nowUs();
        }
        for (;;) {
            if (stopped) return null;
            if (switching) { waitForChange(0); continue; }
            detachInvalidSurface();
            if (surface == null) {
                if (audio) {
                    // Keep the decoder near the audio head while detached. Pulling
                    // several seconds of future video now leaves no timely picture
                    // for a later rebind, even though its audio is still playing.
                    if (paused || audioEnded) return null;
                    long ahead = videoAheadUs(pts);
                    if (ahead <= 0) return null;
                    waitForChange(Math.min(20, (ahead + 999) / 1000));
                    continue;
                }
                waitForChange(0);
                continue;
            }
            if (!paused || preview) {
                long ahead = videoAheadUs(pts);
                if (ahead <= 0 || preview) break;
                waitForChange(Math.min(20, (ahead + 999) / 1000));
            } else {
                waitForChange(0);
            }
        }
        preview = false;
        Surface target = surface;
        if ("ffmpeg".equals(backend)) {
            // CPU-locking the host's native Surface leaves its producer connected
            // until the host destroys it. Own a separate Surface client so that
            // release/reattach can hand the same BufferQueue back to MediaCodec.
            if (cpuSurface == null) {
                android.os.Parcel parcel = android.os.Parcel.obtain();
                try {
                    surface.writeToParcel(parcel, 0);
                    parcel.setDataPosition(0);
                    cpuSurface = Surface.CREATOR.createFromParcel(parcel);
                } finally { parcel.recycle(); }
            }
            target = cpuSurface;
        }
        videoBusy = true;
        return target;
    }

    private void detachInvalidSurface() {
        if (surface != null && !surface.isValid()) {
            Surface invalid = surface;
            bind(null);
            observer.surfaceLost(this, invalid);
        }
    }

    private long firstOnSurface;
    synchronized long firstOnSurface() { return firstOnSurface; }

    synchronized void finishVideo(long ptsUs, boolean didSubmit) {
        videoBusy = false;
        notifyAll();
        if (!didSubmit || stopped) return;
        long actual = ptsUs < 0 ? lastVideo : ptsUs;
        long now = SystemClock.elapsedRealtimeNanos();
        if (firstOnSurface == 0) firstOnSurface = now;
        if (lastSubmissionNs != 0) maxGapNs = Math.max(maxGapNs, now - lastSubmissionNs);
        lastSubmissionNs = paused ? 0 : now;
        lastOffsetUs = actual - clockUs();
        submitted++;
        if (paused) frozenUs = videoJumped ? actual : Math.max(targetUs, actual);
        signalReady(actual);
        if (!firstVideo) {
            firstVideo = true;
            if (firstVideoNs == 0) firstVideoNs = now;
            if (recovery != null && "ffmpeg".equals(backend) && recovery.firstSoftwareSubmissionNanos == 0) {
                recovery = new VideoRecoveryInfo(recovery.failureStage, recovery.failureNanos,
                        recovery.failurePositionUs, recovery.targetUs, actual, now);
            }
            observer.firstVideo(this);
        }
    }

    synchronized int endVideo() {
        while (!stopped && surface != null && nextVideo >= 0 && videoAheadUs(nextVideo) > 0) {
            waitForChange(paused ? 0 : Math.min(20, Math.max(1, videoAheadUs(nextVideo) / 1000)));
        }
        return stopped ? -1 : 0;
    }

    private void releaseCpuSurface() {
        if (cpuSurface != null) { cpuSurface.release(); cpuSurface = null; }
    }

    @Override public synchronized void close() {
        if (!stopped) frozenUs = clockUs();
        finalStats = statistics();
        stopped = true;
        pcm.close();
        if (hardware != null) { hardware.close(); hardware = null; }
        releaseCpuSurface();
        surface = null;
        notifyAll();
    }
}
