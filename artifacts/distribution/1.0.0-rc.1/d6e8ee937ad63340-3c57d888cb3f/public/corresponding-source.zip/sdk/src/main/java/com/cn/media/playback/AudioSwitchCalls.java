package com.cn.media.playback;

/** Package-local seam for deterministic pre-commit and first-new-PCM faults. */
class AudioSwitchCalls {
    boolean prepare(int stream, boolean rollback) { return true; }
    boolean firstWrite(int stream) { return true; }
}
