package com.cn.media.playback;

import android.content.ContentResolver;
import android.os.CancellationSignal;
import android.os.OperationCanceledException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;

/** An uncooperative provider can hold its caller inside Binder after cancellation. */
final class ProviderOpener {
    static final class Busy extends IOException {}
    private final Set<Request> active = new HashSet<>();

    synchronized Request start(MediaSource source, ContentResolver resolver, CancellationSignal signal) throws Busy {
        if (active.size() >= 2) throw new Busy();
        Request request = new Request();
        active.add(request);
        new Thread(() -> {
            InputRange range = null;
            Exception failure = null;
            try {
                range = source.openDeferred(resolver, signal);
            } catch (IOException | RuntimeException e) {
                failure = e;
            } finally {
                request.finish(range, failure);
                finished(request);
            }
        }, "playback-provider").start();
        return request;
    }

    // Take a barrier over just the opens submitted before this stop/release.
    synchronized void afterOutstanding(Runnable action) {
        if (active.isEmpty()) { action.run(); return; }
        AtomicInteger remaining = new AtomicInteger(active.size());
        for (Request request : active) request.barriers.add(() -> {
            if (remaining.decrementAndGet() == 0) action.run();
        });
    }

    private synchronized void finished(Request request) {
        active.remove(request);
        for (Runnable action : request.barriers) action.run();
    }

    static final class Request {
        final ArrayList<Runnable> barriers = new ArrayList<>();
        private boolean done, abandoned;
        private InputRange result;
        private Exception error;

        synchronized void abandon() {
            abandoned = true;
            closeResult();
            notifyAll();
        }

        synchronized void finish(InputRange range, Exception failure) {
            result = range;
            error = failure;
            done = true;
            if (abandoned) closeResult();
            notifyAll();
        }

        private void closeResult() {
            if (result == null) return;
            try { result.close(); } catch (IOException ignored) { }
            result = null;
        }

        synchronized InputRange take() throws IOException {
            while (!abandoned && !done) {
                try { wait(); }
                catch (InterruptedException e) {
                    abandon();
                    Thread.currentThread().interrupt();
                    throw new OperationCanceledException();
                }
            }
            if (abandoned) throw new OperationCanceledException();
            if (error instanceof IOException) throw (IOException)error;
            if (error instanceof RuntimeException) throw (RuntimeException)error;
            InputRange range = result;
            result = null;
            return range;
        }
    }
}
