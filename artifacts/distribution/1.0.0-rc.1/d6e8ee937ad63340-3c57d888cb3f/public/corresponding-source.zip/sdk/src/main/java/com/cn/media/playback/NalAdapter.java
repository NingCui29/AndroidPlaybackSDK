package com.cn.media.playback;

import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.Map;

/** AVC/HEVC configuration records and Annex B access units. Packet order and PTS stay with the demuxer. */
final class NalAdapter {
    static final int LIMIT = 4 * 1024 * 1024;
    private final boolean hevc;
    private final Map<Integer,byte[]> sets = new LinkedHashMap<>();
    private final Map<Integer,NalParameters> ids = new LinkedHashMap<>();
    private int lengthBytes, storedBytes, revision, activePps = -1;
    private boolean randomAccess;

    NalAdapter(boolean hevc, ByteBuffer extra) {
        this.hevc = hevc;
        if (extra == null || !extra.hasRemaining()) return;
        ByteBuffer b = extra.slice();
        check(b.remaining() <= LIMIT);
        if (b.get(0) != 1) { collect(b); return; }
        if (hevc) {
            check(b.remaining() >= 23);
            lengthBytes = (b.get(21) & 3) + 1;
            b.position(22);
            int arrays = unsigned(b);
            for (int i = 0; i < arrays; i++) {
                unsigned(b);
                int count = word(b);
                for (int n = 0; n < count; n++) record(b);
            }
        } else {
            check(b.remaining() >= 7);
            lengthBytes = (b.get(4) & 3) + 1;
            b.position(5);
            int sps = unsigned(b) & 31;
            for (int i = 0; i < sps; i++) record(b);
            int pps = unsigned(b);
            for (int i = 0; i < pps; i++) record(b);
        }
    }

    private static void check(boolean valid) {
        if (!valid) throw new IllegalArgumentException("Malformed or oversized video access unit");
    }

    private static int unsigned(ByteBuffer b) { check(b.hasRemaining()); return b.get() & 255; }
    private static int word(ByteBuffer b) { return (unsigned(b) << 8) | unsigned(b); }

    private int type(int first) { return hevc ? (first >> 1) & 63 : first & 31; }

    private boolean parameter(int type) {
        return hevc ? type >= 32 && type <= 34 : type == 7 || type == 8;
    }

    private void record(ByteBuffer b) {
        int size = word(b);
        check(size > 0 && size <= b.remaining());
        int end = b.position() + size;
        addSet(b, b.position(), end);
        b.position(end);
    }

    private void addSet(ByteBuffer b, int begin, int end) {
        int type = type(b.get(begin));
        if (!parameter(type)) return;
        ByteBuffer part = b.duplicate();
        part.position(begin).limit(end);
        byte[] bytes = new byte[part.remaining()];
        part.get(bytes);
        NalParameters p = NalParameters.read(bytes, hevc, type);
        int key = (type << 16) | p.id;
        byte[] old = sets.get(key);
        if (Arrays.equals(old, bytes)) return;
        int previous = old == null ? 0 : old.length + 4;
        check(bytes.length <= LIMIT - (storedBytes - previous) - 4);
        sets.put(key, bytes);
        ids.put(key, p);
        storedBytes += bytes.length + 4 - previous;
        revision++;
    }

    private static int start(ByteBuffer b, int pos) {
        for (int i = pos; i + 2 < b.limit(); i++)
            if (b.get(i) == 0 && b.get(i + 1) == 0 && b.get(i + 2) == 1) return i;
        return -1;
    }

    private interface Visitor { void nal(ByteBuffer data, int begin, int end); }
    private void visit(ByteBuffer data, Visitor visitor) {
        ByteBuffer b = data.slice();
        check(b.remaining() > 0 && b.remaining() <= LIMIT);
        if (lengthBytes != 0) {
            while (b.hasRemaining()) {
                check(b.remaining() >= lengthBytes);
                long size = 0;
                for (int i = 0; i < lengthBytes; i++) size = (size << 8) | unsigned(b);
                check(size > 0 && size <= b.remaining());
                int end = b.position() + (int)size;
                visitor.nal(b, b.position(), end);
                b.position(end);
            }
        } else {
            int prefix = start(b, 0);
            check(prefix >= 0);
            for (int i = 0; i < prefix; ++i) check(b.get(i) == 0);
            while (prefix >= 0) {
                int begin = prefix + 3;
                prefix = start(b, begin);
                int end = prefix < 0 ? b.limit() : prefix;
                while (end > begin && b.get(end - 1) == 0) end--;
                check(end > begin);
                visitor.nal(b, begin, end);
            }
        }
    }

    private void inspect(ByteBuffer b, int begin, int end) {
        int first = b.get(begin) & 255, type = type(first);
        check((first & 128) == 0 && (!hevc || (end - begin >= 2 && (b.get(begin+1) & 7) != 0)));
        if (parameter(type)) addSet(b, begin, end);
        else if (hevc ? type >= 16 && type <= 21 : type == 5) {
            byte[] header = new byte[Math.min(64, end - begin)];
            ByteBuffer data = b.duplicate();
            data.position(begin);
            data.get(header);
            int id = NalParameters.picturePps(header, hevc);
            if (id >= 0) { activePps = id; randomAccess = true; }
        }
    }

    void collect(ByteBuffer packet) { randomAccess = false; visit(packet, this::inspect); }

    boolean randomAccess() { return randomAccess; }

    int revision() { return revision; }

    boolean sameConfiguration(NalAdapter other) {
        if (lengthBytes != other.lengthBytes || sets.size() != other.sets.size()) return false;
        for (Map.Entry<Integer,byte[]> e : sets.entrySet())
            if (!Arrays.equals(e.getValue(), other.sets.get(e.getKey()))) return false;
        return true;
    }

    NalParameters activeSps() {
        int ppsType = hevc ? 34 : 8, spsType = hevc ? 33 : 7;
        for (Map.Entry<Integer,NalParameters> e : ids.entrySet()) {
            NalParameters p = e.getValue();
            if ((e.getKey() >>> 16) != ppsType || (activePps >= 0 && activePps != p.id)) continue;
            NalParameters sps = ids.get((spsType << 16) | p.parent);
            if (sps != null && (!hevc || ids.containsKey((32 << 16) | sps.parent))) return sps;
        }
        return null;
    }

    boolean complete() {
        return activeSps() != null;
    }

    ByteBuffer configuration(int index) {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        int first = hevc ? 32 : 7 + index, last = hevc ? 34 : first;
        for (int type = first; type <= last; type++) {
            for (byte[] set : sets.values()) if (type(set[0]) == type) {
                bytes.write(0); bytes.write(0); bytes.write(0); bytes.write(1);
                bytes.write(set, 0, set.length);
            }
        }
        return ByteBuffer.wrap(bytes.toByteArray());
    }

    int copy(ByteBuffer packet, ByteBuffer output, boolean configuredWithThisPacket) {
        int base = output.position();
        visit(packet, (data, begin, end) -> {
            if (configuredWithThisPacket && parameter(type(data.get(begin)))) return;
            int size = end - begin;
            check(size + 4 <= output.remaining() && size + 4 <= LIMIT - (output.position() - base));
            output.put((byte)0).put((byte)0).put((byte)0).put((byte)1);
            ByteBuffer part = data.duplicate();
            part.position(begin).limit(end);
            output.put(part);
        });
        return output.position() - base;
    }

    int adaptiveCopy(ByteBuffer packet, ByteBuffer output) {
        int pos = output.position();
        ByteBuffer first = configuration(0);
        ByteBuffer second = hevc ? null : configuration(1);
        int bytes = first.remaining() + (second == null ? 0 : second.remaining());
        check(bytes <= LIMIT && bytes <= output.remaining());
        output.put(first);
        if (second != null) output.put(second);
        ByteBuffer bounded = output.slice();
        bounded.limit(Math.min(bounded.remaining(), LIMIT - bytes));
        output.position(output.position() + copy(packet, bounded, true));
        return output.position() - pos;
    }
}
